<?php
require 'config.php';

if (is_login()) {
	require 'admin_form.php';
}else{
	require 'login.php';
}
?>