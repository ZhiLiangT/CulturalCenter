<?php
header("location:../admin.php");
?>