<!DOCTYPE html>
<html lang="en">
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
	<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
	<title>关于终端</title>
	<link rel="shortcut icon" href="img/favicon.ico" />
	<link rel="stylesheet" type="text/css" href="./bootstrap/css/bootstrap.min.css">
	<link rel="stylesheet" type="text/css" href="./jGrowl/jquery.jgrowl.css">
	<style type="text/css">
	.detail{
		padding-left: 10%; 
		text-align: left;
		height:40px;
	}
	.selData{
		display:block;
		float:right; 
		width:70%;
		font-size:18px;
		color:#FFFFFF;
		height:30px;
		text-align:center;
		line-height:30px;
		background:#3090C7;
	}
	</style>
</head>

<body class="text-center">
	<div style="width:90%;">
		<div id="div_step1_begin">
			<h2 style="margin-top:20px;margin-bottom:20px;text-align:center;">设备信息</h2>
			<div class="detail" >软件版本：<span class="selData" id="version"></span>
			</div>
			<div class="detail" >硬盘容量：<span class="selData" id="capacity1"></span>
			</div>
			<div class="detail" ><span class="selData" id="capacity2"></span>
			</div>
			<div class="detail" >MAC地址：<span class="selData" id="mac"></span>
			</div>
			<div class="detail" >联网状态：<span class="selData" id="lineStatus"></span>
			</div>
		</div>
	</div>

</body>
	<script type="text/javascript" src="./js/jquery.js"></script>
	<script type="text/javascript" src="./js/common.js"></script>
	<script type="text/javascript" src="./bootstrap/js/bootstrap.min.js"></script>
	<script type="text/javascript" src="./jGrowl/jquery.jgrowl.min.js"></script>
	<script type="text/javascript">
		var version = "";
		var capacity1 = "";
		var capacity2 = "";
		var mac = "";
		var lineStatus = "";
		$(function(){
			getDetails();
		});
		function getDetails(){
			var url = host + '/aboutBox/';
			$.ajax({
					timeout: 60000,
					url: url,
					type: 'POST',
					dataType: 'jsonp',
					jsonp:"callback", 
					success: function(json){
						if(json["status"] == 1){
							version = json["data"]["version"];
							capacity1 = json["data"]["storageInfo"]["totalSize"];
							capacity2 = json["data"]["storageInfo"]["freeSize"];
							mac = json["data"]["boxId"];
							lineStatus = json["data"]["netStatus"];
							$("#version").text(version);
							$("#capacity1").text("总容量："+ getSize(capacity1));
							$("#capacity2").text("剩余容量："+ getSize(capacity2));
							$("#mac").text(mac);
							if (lineStatus == "true") {
								$("#lineStatus").text("在线");
							}else{
								$("#lineStatus").text("离线");
							}
						}else{
							$.jGrowl(json["msg"]+"",{position:"center"});
						}
					},
					error: function(e){
						alert(JSON.stringify(e));
						$.jGrowl("数据获取失败,请稍后重试!",{position:"center"});
					}
				});
		}
		function getSize(size){
			var tmpSizes = parseInt(size);
			if(tmpSizes > 1024 || tmpSizes == 1024){
				var ret = tmpSizes / 1024+"";
				ret  = ret.split(".")[0]; 
				return ret + "GB";
			} else{
				return tmpSizes + "MB";
			}
		}
	</script>

</html>