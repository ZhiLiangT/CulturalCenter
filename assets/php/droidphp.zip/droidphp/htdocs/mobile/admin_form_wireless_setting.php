<!DOCTYPE html>
<html lang="en">
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
	<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
	<title>无线网络设置</title>
	<link rel="shortcut icon" href="img/favicon.ico" />
	<link rel="stylesheet" type="text/css" href="./bootstrap/css/bootstrap.min.css">
	<link rel="stylesheet" type="text/css" href="./jGrowl/jquery.jgrowl.css">
	<style type="text/css">
	body {
		background-color: #fff;
	}
	.switch_box{
		width: 100px;
		height: 30px;
		border: 1px solid #278fff;
		color: #000;
		display: inline-block;
	}

	.switch_selected{
		width: 49px;
		height: 28px;
		background: #278fff;
		color: #fff;
		display: inline-block;
		text-align: center;
		padding: 5px;
	}

	.switch_unselected{
		width: 49px;
		height: 28px;
		background: #fff;
		color: #000;
		display: inline-block;
		text-align: center;
		padding: 5px;
	}
	</style>
</head>
<body class="text-center">
	<div class="text-left" style="width:90%;margin:0 auto;padding:4px 0;overflow:hidden;">
		<span id="cable_status" style="color: #5cb85c;font-weight: bold;"></span>
		<a class="btn-md" href="admin.php" style="color:#666;text-decoration:underline;float:right;">返回管理页</a>
	</div>
	<div style="width:90%;margin:0 auto;">
		<div id="div_step1_begin">
			<h2 style="margin-top:0;">无线网络连接设置</h2>
			<div style="height: 50px; padding-top: 10px; padding-left: 0px; text-align: left;">
				<div style="height: 30px; line-height: 30px; display: inline-block; float: left; ">网络类型：</div>
				<div class="switch_box" style="float: left; ">
					<div id="selected2g" class="switch_selected" style="float: left; " onclick="switchSelected('2g')">2.4G</div>
					<div id="selected5g" class="switch_unselected" style="float: left; " onclick="switchSelected('5g')">5G</div>
				</div>
				<input class="btn btn-default" style="width:60px;float:right;margin-right:0px;" type="submit" value="刷新" onClick="getWifiListDo(wifiSelected);"/>	
			</div>
			<div id="wifiList">
				<table class="table table-hover" >
					<thead>
						<tr>
							<th class="SSID text-center">Wi-Fi 名称</th>
							<th class="current"></th>
							<th class="Signal text-center">信号</th>
						</tr>
					</thead>
					<tbody id="wifi"></tbody>
				</table>
			</div>
		</div>
	</div>
	<div id="loading" class="modal fade" tabindex="-1" data-backdrop="static" role="dialog" aria-hidden="true" style="top:30%;">
		<div class="modal-dialog modal-sm">
			<div class="modal-content">
				<!-- {/*模态框内容 START*/}  -->
				<div id="loadingInfo" class="modal-body text-center">
					刷新wifi列表，请稍后...
				</div>
				<!-- {/*模态框内容 END*/}  -->
			</div>
		</div>
	</div>
	<!-- {/* 设置wifi START */} -->
	<div id="selectWifi" class="modal fade" tabindex="-1" data-backdrop="static" role="dialog" aria-hidden="true" style="top:30%;">
		<div class="modal-dialog modal-md">
			<div class="modal-content">
				<!-- {/* 模态框内容 START  */} -->
				<div class="modal-body text-center form-horizontal">
					<div class="form-group">
						<label for="current_wifi_ssid" class="col-xs-3 control-label">名称</label>
						<div class="col-xs-8">
							<input type="text" class="form-control" id="current_wifi_ssid" name="relayName" value="" placeholder="" disabled="disabled"></div>
						<div class="col-xs-1"></div>
					</div>
					<div class="form-group">
						<label for="current_wifi_pass" class="col-xs-3 control-label">密码</label>
						<div class="col-xs-8">
							<input type="password" class="form-control" id="current_wifi_pass" name="relayPassword" value="" placeholder=""></div>
						<div class="col-xs-1"></div>
						<div class="col-xs-3"></div>
						<div class="col-xs-8">
							<div class="checkbox" style="text-align: left;">
								<label>
									<input type="checkbox" onclick="displayPassword(this);"/>				
									显示密码
								</label>
							</div>
						</div>
					</div>
				</div>
				<!-- {/* 模态框内容 END  */} -->
				<!-- {/* 模态框底部 START */} -->
				<div class="modal-footer">
					<button type="button" class="btn btn-warning" data-dismiss="modal">
						取消
					</button>
					<button type="button" id="btnSelectWifi" class="btn btn-primary" onclick="selectWifiDo();">
						连接
					</button>
				</div>
				<!-- 模态框底部 END  -->
			</div>
		</div>
	</div>
	<!-- {/* 设置wifi */} -->
</body>
	<script type="text/javascript" src="./js/jquery.js"></script>
	<script type="text/javascript" src="./js/common.js"></script>
	<script type="text/javascript" src="./bootstrap/js/bootstrap.min.js"></script>
	<script type="text/javascript" src="./jGrowl/jquery.jgrowl.min.js"></script>
<script type="text/javascript">
	var wifiSelected = '#wifi2g';
	var current_wifi_ssid = "";
	var wanStatus = false;
	var isNetworkOk = false;
	var wifiList;
	var boxWifi;

	$(function(){
		getWifiListDo(wifiSelected);
		getWanStatus();
		mIsNetworkOk();
		getWifiName();
	});

	function getWifiListDo(e){
		showLoading(true,"刷新wifi列表，请稍后...");
		$.ajax({
				timeout: 60000,
				url: host + '/getWifiList/',
				type: 'POST',
				dataType: 'jsonp',
				jsonp:"callback",
				success: function(json){
					myLog(json);
					wifiList = json;
					showLoading(false,"刷新wifi列表，请稍后...");
					aaa(json,e);
				},
				error: function(){
					$.jGrowl("获取wifi列表失败,请稍后重试!",{position:"center"});
					showLoading(false,"刷新wifi列表，请稍后...");
				}
			});
	}

	function showLoading(show,info){
		if(show){
			$("#loadingInfo").html(info);
			$("#loading").modal("show");
		}else{
			$("#loading").modal("hide");
		}
	}

	function setLoadingInfo(info){
		$("#loadingInfo").html(info);
	}

	function displayPassword(e) {
		var temp = document.getElementById('current_wifi_pass');
		if(e.checked){
			temp.type = "text";
		}else{
			temp.type = "password";
		}
		temp.focus();
	}
	
	// 获取服务宝当前wifi名称
	function getWifiName(){
		$.ajax({
			url: host + "/getWifiName",
			type: 'post',
			dataType: "jsonp",
			success: function(json){
				boxWifi = json;
			}
		});
	}

	//获取网线是否插入
	function getWanStatus(){
		$.ajax({
			url: host + "/getWanStatus",
			type: 'post',
			dataType: "jsonp",
			success: function(json){
				var tempStatus = json.result;
				if(tempStatus){
					$("#cable_status").text("网线已插入");
					if(!wanStatus){
						$.jGrowl("网线已插入!",{position:"center"});
					}
				}else{
					$("#cable_status").text("");
					if(wanStatus){
						$.jGrowl("网线已拔出!",{position:"center"});
					}
				}
				wanStatus = tempStatus;
			}
		});
		setTimeout("getWanStatus();", 5000);
	}

	//获取是否已联网，并改变显示内容
	function mIsNetworkOk(){
		$.ajax({
			timeout: 30000,
			url: host + '/isInternetOk/',
			type: 'POST',
			dataType: 'jsonp',
			jsonp:"callback",
			success: function(json){
				isNetworkOk = json.result;
			},
			error: function(){
				
			}
		});
		setTimeout("mIsNetworkOk();", 10000);
	}

	//加载无线列表
	function aaa(wifiList, e) {
	  	var l = wifiList.length;
	    var tbody = "";
	    var w = "";
	    if (e == "#wifi2g") {
	    	w = "2.4G";
	    } else {
	    	w = "5G";
	    };

	  	for (var i = 0; i < wifiList.length; i++) {
	  		var wifi = wifiList[i];
	  		var net_way = wifi.net_way;

	  		if (w == "2.4G" && net_way == 1) {
	  			continue;
	  		}else if (w == "5G" && net_way == 0) {
	  			continue;
	  		};
	  		var SSID = wifi.SSID;
	  		var Signal = wifi.Signal;
	  		var imgPath = 4;
	  		if (Signal > 25 ) {
	  			imgPath = 3;
	  		}
	  		if (Signal > 50) {
	  			imgPath = 2;
	  		}
	  		if (Signal > 75) {
	  			imgPath = 1;
	  		}
	  		var Encrypt = wifi.Encrypt;
	  		if (Encrypt != "no") {
	  			imgPath += 4;
	  		}
	  		
	  		var trs = "";

	  		if (wifi.isConn || wifi.isConn == "true") {
	  			if(isNetworkOk){
	  				trs += "<tr onClick='pop("+i+")' alt='"+i+"'><td class=\"td SSID\">" + SSID +"</td><td class=\"td current\">已连接</td><td class=\"td Signal\"><img src='image/"+imgPath+".png' ></td></tr>";
	  			}else{
	  				trs += "<tr onClick='pop("+i+")' alt='"+i+"'><td class=\"td SSID\">" + SSID +"</td><td class=\"td current\">已保存</td><td class=\"td Signal\"><img src='image/"+imgPath+".png' ></td></tr>";
	  			}
	  		}else{
	  			trs += "<tr onClick='pop("+i+")' alt='"+i+"'><td class=\"td SSID\">" + SSID +"</td><td class=\"td current\"></td><td class=\"td Signal\"><img src='image/"+imgPath+".png' ></td></tr>";
	  		};

			
	  		tbody += trs;
	  	};
	  	document.getElementById("wifi").innerHTML = "";
		$("#wifi").append(tbody);
	}

	function pop(n){
		if (wanStatus == true || wanStatus == "true" ) {
			$.jGrowl("请先将网线拔掉再连接无线网络！", { position:'center' } );
		}else{
			var wifi = wifiList[n];
			$("#current_wifi_ssid").val(wifi.SSID);
			$("#current_wifi_pass").val("");
			$("#btnSelectWifi").attr("onclick","selectWifiDo("+n+");");
			$("#current_wifi_pass").attr("disabled",wifi.Encrypt == "no");
			$("#selectWifi").modal("show");
		}
	}

	function selectWifiDo(n){
		var wifi = wifiList[n];
		var wifiPass = $("#current_wifi_pass").val();
		wifiPass = $.trim(wifiPass);
		if(wifi.Encrypt == "no"){
			wifiPass = "";
		}else{
			if(wifiPass == "" || wifiPass.length < 8){
				$.jGrowl("wifi密码至少8位!", { position:'center' } );
				$("#current_wifi_pass").focus();
				return;
			}
		}
		$("#selectWifi").modal("hide");
		var t1 = 60;
		showLoading(true,"1.正在设置,请稍候...("+ t1 +")<br/>如果稍后页面没有刷新,请重新连接服务宝wifi并刷新当前页面。");
		var tt1 =setInterval(function(){
			if(t1==0){
				clearTimeout(tt1);
				showLoading(false,"");
			}
			setLoadingInfo("1.正在设置,请稍候...("+ t1-- +")<br/>如果稍后页面没有刷新,请重新连接服务宝wifi并刷新当前页面。");
		},1000);
		$.ajax({
			// timeout: 30000,
			url: host + '/setNetWireless/',
			type: 'POST',
			data: {
				"wifiSSID" : wifi.SSID,
				"encrypt" : wifi.Encrypt,
				"password" : wifiPass,
				"netType" : wifi.net_way
			},
			dataType: 'jsonp',
			jsonp:"callback",
			success: function(json){
				myLog(json);
				if(json.result){
					// getWifiListDo(wifiSelected);
					clearTimeout(tt1);
					var t = 60;
					var tt =setInterval(function(){
						if(t==0){
							clearTimeout(tt);
							showLoading(false,"");
							window.location.href="admin.php?first=1";
						}
						setLoadingInfo("2.正在进行网络设置,请稍候...("+ t-- +")<br/>如果稍后页面刷新失败,请重新连接服务宝wifi。");
					},1000);
				}else{
					$.jGrowl("密码错误,请重试!", { position:'center' } );
					$("#loading").modal("hide");
					$("#selectWifi").modal("show");
				}
			},
			error: function(){
				$.jGrowl("连接失败,请重试!", { position:'center' } );
				$("#loading").modal("hide");
				$("#selectWifi").modal("show");
			}
		});
	}

	//切换WiFi类型
	function switchSelected(e){
		if ( e == '2g' ){
			getWifiListDo('#wifi2g');
			selected2g.className = "switch_selected";
			selected5g.className = "switch_unselected";
			wifiSelected = '#wifi2g';
		} else {
			getWifiListDo('#wifi5g');
			selected5g.className = "switch_selected";
			selected2g.className = "switch_unselected";
			wifiSelected = '#wifi5g';
		}
	}

</script>
</html>