<!DOCTYPE html>
<html lang="en">
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
	<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
	<title>离线升级程序</title>
	<link rel="shortcut icon" href="img/favicon.ico" />
	<link rel="stylesheet" type="text/css" href="./bootstrap/css/bootstrap.min.css">
	<link rel="stylesheet" type="text/css" href="./jGrowl/jquery.jgrowl.css">
</head>

<body>
	<div>
		<div style="height:40px;text-align:center;line-height:40px;margin-top:20px;margin-left:6%;margin-right:6%;background:#3090C7;" >
			<div id="message" style="font-size:22px;color:#FFFFFF"></div>
		</div>
	</div>
	<div id="loading" class="modal fade" tabindex="-1" data-backdrop="static" role="dialog" aria-hidden="true" style="top:30%;">
		<div class="modal-dialog modal-sm">
			<div class="modal-content">
				<!-- {/*模态框内容 START*/}  -->
				<div id="loadingInfo" class="modal-body text-center">
					正在启动离线升级应用，请稍后...
				</div>
				<!-- {/*模态框内容 END*/}  -->
			</div>
		</div>
	</div>
</body>
	<script type="text/javascript" src="./js/jquery.js"></script>
	<script type="text/javascript" src="./js/common.js"></script>
	<script type="text/javascript" src="./bootstrap/js/bootstrap.min.js"></script>
	<script type="text/javascript" src="./jGrowl/jquery.jgrowl.min.js"></script>
	<script type="text/javascript">
		var progressMsg = "";
		$(function(){
			showLoading(true,"正在启动离线升级应用，请稍后...");
			startApkOutline();
			setTimeout(updateApkOutline, 5000);
		});
		function showLoading(show,info){
			if(show){
				$("#loadingInfo").html(info);
				$("#loading").modal("show");
			}else{
				$("#loading").modal("hide");
			}
		}
		function startApkOutline(){
			$.ajax({
				timeout: 10000,
				url: host + '/updateApkAndWebFromUsb/',
				type: 'POST',
				dataType: 'jsonp',
				jsonp:"callback",
				success: function(){
				},
				error: function(){
					$.jGrowl("程序启动失败,请稍后重试!",{position:"center"});
				}
			});
		}
		function updateApkOutline(){
			$.ajax({
				url: host + '/updateApkAndWebFromUsbProgress/',
				type: 'POST',
				dataType: 'jsonp',
				jsonp:"callback",
				success: function(json){
					progressMsg = json["msg"];
					$("#message").text(progressMsg);
					showLoading(false,"正在启动离线升级应用，请稍后...");
				},
				error: function(){
					$.jGrowl("更新进度获取失败!",{position:"center"});
					showLoading(false,"正在启动离线升级应用，请稍后...");
				}
			});
			setTimeout(updateApkOutline, 3000);
		}
	</script>

</html>