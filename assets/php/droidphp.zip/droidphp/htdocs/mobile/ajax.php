<?php
require 'config.php';

define('AJAX_ERROR',   0);
define('AJAX_SUCCESS', 1);

$mtd = $_GET["mtd"];

$mtdArr = array(
	'like_do',//点赞
	'download_do',//点赞
	'like_pull',//好评榜上拉刷新
	'rank_pull',//浏览排行上拉刷新
	'choose_pull',//最近更新上拉刷新
	'series_pull', //专题列表上拉刷新
	'series_list_pull', //专题资源列表上拉刷新
	'search_pull',  //搜索结果列表上拉刷新
	'channel_pull', //栏目资源上拉刷新
	'login_do',//管理员登录
	'logout_do',//管理员退出
);

if (in_array($mtd, $mtdArr)) {
	// 添加了异常的捕获机制
	try {
		$mtd();
	} catch (Exception $e) {
		$ret = array();
		$ret["status"] = AJAX_ERROR;// 0表示ERROR
		$ret["msg"]    = $e->getMessage();
		print_j($ret);
		exit;
	}
} else {
	$ret = array();
	$ret["status"] = AJAX_ERROR;// 0表示ERROR
	$ret["msg"]    = "method not found";
	print_j($ret);
	exit;
}

//点赞
function like_do(){
	$res_id = get_require_value('id');
	update_like_record($res_id);
	$data = get_like_cnt($res_id);
	$ret = new stdClass();
	$ret->status = 'success';
	$ret->msg = $res_id;
	$ret->datalist = $data;
	print_j($ret);
	exit();
}

//下载
function download_do(){
	$res_id = get_require_value('id');
	update_download_record($res_id);
	$data = get_download_cnt($res_id);
	$ret = new stdClass();
	$ret->status = 'success';
	$ret->msg = $res_id;
	$ret->datalist = $data;
	print_j($ret);
	exit();
}

//好评榜上拉刷新

function like_pull(){
	$like_page = get_require_value('page');
	$data = update_like_cnt_list($like_page);
	$ret = new stdClass();
	$ret->status = 'success';
	$ret->msg = $like_page;
	$ret->datalist = $data;
	print_j($ret);
	exit();
}


//浏览排行上拉刷新

function rank_pull(){
	$rank_page = get_require_value('page');
	$data = update_rank_cnt_list($rank_page);
	$ret = new stdClass();
	$ret->status = 'success';
	$ret->msg = $rank_page;
	$ret->datalist = $data;
	print_j($ret);
	exit();
}

//最近更新上拉刷新

function choose_pull(){
	$choose_page = get_require_value('page');
	$data = update_choose_cnt_list($choose_page);
	$ret = new stdClass();
	$ret->status = 'success';
	$ret->msg = $choose_page;
	$ret->datalist = $data;
	print_j($ret);
	exit();
}

//专题列表上拉刷新

function series_pull(){
	$series_page = get_require_value('page');
	$data = update_series_cnt_list($series_page);
	$ret = new stdClass();
	$ret->status = 'success';
	$ret->msg = $series_page;
	$ret->datalist = $data;
	print_j($ret);
	exit();
}

//专题资源列表上拉刷新

function series_list_pull(){
	$series_list_page = get_require_value('page');
	$series_id = get_require_value('series_id');
	$data = update_series_list_cnt($series_id,$series_list_page);
	$ret = new stdClass();
	$ret->status = 'success';
	$ret->msg = $series_list_page;
	$ret->datalist = $data;
	print_j($ret);
	exit();
}

//搜索结果列表上拉刷新

function search_pull(){
	$search_page = get_require_value('page');
	$isnull = get_require_value('isnull');
	if ($isnull == 0) {
		$search_name = get_require_value('searchName');
		$data = update_search_cnt($search_page,$isnull,$search_name);
	}else{
		$data = update_search_cnt($search_page,$isnull);
	}
	$ret = new stdClass();
	$ret->status = 'success';
	$ret->msg = $search_page;
	$ret->datalist = $data;
	print_j($ret);
	exit();
}

//栏目资源上拉刷新

function channel_pull(){
	$channel_page = get_require_value('page');
	$main_menu_id = get_require_value('main_menu_id');
	$is_null = get_require_value('isNull');
	if ($is_null == 0) {
		$sub_menu_id = get_require_value('sub_menu_id');
		$data = update_channel_two_cnt($sub_menu_id,$channel_page);
	}else{
		$data = update_channel_one_cnt($main_menu_id,$channel_page);
	}
	$ret = new stdClass();
	$ret->status = 'success';
	$ret->msg = $channel_page;
	$ret->datalist = $data;
	print_j($ret);
	exit();
}

//管理员登录
function login_do(){
	global $CFG;
	$pwd = get_require_value('pwd');
	$pwd = my_md5($pwd,16);
	$ret = new stdClass();
	if ($pwd == $CFG->password) {
		$ret->status = 'success';
		$_SESSION["cur_ssid"] = "is_login";
		$ret->login = $_SESSION["cur_ssid"];
	}else{
		$ret->status = 'fail';
	}
	print_j($ret);
	exit();
}

//管理员退出登录
function logout_do(){
	global $CFG;
	$ret = new stdClass();
	if (isset($_SESSION["cur_ssid"])) {
		unset($_SESSION["cur_ssid"]);
	}
	$ret->status = 'success';
	
	print_j($ret);
	exit();
}