<?php
	require 'config.php';
?>

<!DOCTYPE html>
<html>
	<head>
		<meta charset="UTF-8">
		<meta name="viewport" content="width=device-width, initial-scale=1,maximum-scale=1,user-scalable=no">
		<title>频道资源</title>
		<link rel="stylesheet" href="css/reset.css" />
		<link rel="stylesheet" href="css/bootstrap.min.css" />
		<link rel="stylesheet" href="css/font-awesome/font-awesome.min.css" />
		<link rel="stylesheet" href="css/lcn.css" />
		<link rel="stylesheet" href="css/mui.min.css">
		<script type="text/javascript" src="js/jquery-2.1.1.min.js"></script>
	</head>
	<body>
		<div class="list-hearder">
		<?php
			
			$main_menu_id = get_option_value('main_menu_id',null);
			$sub_menu_id_at = get_option_value('sub_menu_id',null);
			$sub_menu_name_list = get_sub_menu_name($main_menu_id);
			$dir_root = $CFG->res_dirroot;

            echo "<input type='hidden' id='main_menu_id' value='{$main_menu_id}'>";
            echo "<input type='hidden' id='sub_menu_id' value='{$sub_menu_id_at}'>";
            echo "<input type='hidden' id='dir_root' value='{$dir_root}'>";

			if ($sub_menu_name_list == null) {
				echo "<div style='padding-left:10px;'>没有二级分类</div>";
			}else{
				echo "<a href=\"javascript:;\" onclick=\"window.location.href='channel-list.php?main_menu_id={$main_menu_id}';\">全部</a>";
					foreach ($sub_menu_name_list as $key => $value) {

			            $sub_menu_name = $value->SUB_MENU_NAME;
			            $sub_menu_id = $value->SUB_MENU_ID;
			            $index = $key + 1;

			        	echo "<a href=\"javascript:;\" 
			        	onclick=\"window.location.href='channel-list.php?main_menu_id={$main_menu_id}&sub_menu_id={$sub_menu_id}&sur={$index}';  \">{$sub_menu_name}</a>";
				    }

			}

		?>
	    </div>

		<?php
			if ($sub_menu_id_at == null) {
				$sub_menu_res_list = get_sub_menu_res($main_menu_id);
			}else{
				$sub_menu_res_list = get_sub_res($sub_menu_id_at);
			}

			if ($sub_menu_res_list == null) {
				echo "<div style='padding-left:10px;'>没有相关资源</div>";
			}else{
					echo "<div class='paddingbottom'><ul class='culture-list' id='intangible'>";
					foreach ($sub_menu_res_list as $key => $value) {
			            $res_id = $value->RES_ID;
			            $res_name = $value->RES_NAME;
			            $res_path = $value->PATH;
			            $sub_menu_id = $value->SUB_MENU_ID;
			            $main_menu_name = $value->MAIN_MENU_NAME;
			            $notice = $value->NOTICE;
			            $cnt = $value->CNT;
			            $like_cnt = $value->LIKE_CNT;
			            if ($cnt == null) {
			            	$cnt = 0;
			            }
			            if ($like_cnt == null) {
			            	$like_cnt = 0;
			            }

						$img = $CFG->res_dirroot.'/res'.urlencode($res_path).'/img.jpg';
			            $img = str_replace("+","%20",$img);
			        	$img = str_replace("%2F","/",$img);
			            echo "<li>";
						echo "<a onclick=\"window.open('play-detail.php?res_id={$res_id}&sub_menu_id={$sub_menu_id}','_blank')\" style='text-decoration:none;'>";
			            echo "<img src='{$img}' />";
			            echo "<div class='introduce'>";
			            echo "<span class='title' style='color:#333;'>{$res_name}</span>";
			            echo "<div class='typesa'><span>{$main_menu_name}</span><span>{$notice}</span></div>";
			            echo "<div class='operation'><span><i class='fa fa-eye'></i>$cnt</span><span><i class='fa fa-heart'></i>$like_cnt</span></div>";
			            echo "</div>";
						echo "</a>";
			            echo "</li>";
						
		        	}
		        	echo "<div class='clearfix'></div>";
		        	echo "</ul>";
		        	echo "<div id='error' style='text-align:center;padding-bottom: 20px;'><a onclick='javascript:channel_more()'><input style='width:100%; height:40px;border-left:0px;border-right:0px;' type='button' value='加载更多'/></a></div></div>";
			}

		?>

	<ul class="atroot aatroot">
			<li>
				<a href="index.php">
				<img src="img/jingan.png">
				<span>精选</span>
				</a>
			</li>
			<li>
				<a href="channel.php">
				<img src="img/pinli.png">
				<span class="zantxt">频道</span>
				</a>
			</li>
			<li>
				<a href="series.php">
				<img src="img/zhuanan.png">
				<span>专题</span>
				</a>
			</li>
			<li>
				<a href="search.php">
				<img src="img/souan.png">
				<span>搜索</span>
				</a>
			</li>
			
			<div class="clearfix"></div>
	</ul>

	<script src="js/mui.min.js"></script>
	<script type="text/javascript" charset="utf-8">
			mui.init({
				swipeBack:true //启用右滑关闭功能
			});
			var slider = mui("#slider");
			slider.slider({
						interval: 2000
					});

		$(document).ready(function() {
			var sur = getUrlPara("sur");
			if (sur>2) {
				$(".list-hearder")[0].scrollLeft=sur*50;
			}
			$(".list-hearder a").removeClass("active");
			$(".list-hearder a").eq(sur).addClass("active")
			
		});
		
		var count = 1;
		var isSubNull = 1;
		var main_menu_id = $("#main_menu_id").val();
		var sub_menu_id = $("#sub_menu_id").val();
		if (sub_menu_id != "") {
			isSubNull = 0;
		}
		var dir_root = $("#dir_root").val();

		function channel_more() {
			count++;
		        $.ajax({ 
		                url: "ajax.php?mtd=channel_pull",
		                type: "post",
		                data: {page: count, 
		                	   main_menu_id: main_menu_id, 
		                	   sub_menu_id: sub_menu_id, 
		                	   isNull: isSubNull
		                	  },
		                dataType: "json",
		                success: function(ret){
		                    if (ret.status == 'success') {
		                    	
			                    var ul = document.getElementById("intangible");
			                    var div2 = document.createElement("div");
			                    div2.setAttribute("class","clearfix");
		                    	for(var i=0;i<ret.datalist.length;i++){  

								var res_id = ret.datalist[i].RES_ID;
								var res_name = ret.datalist[i].RES_NAME;
					            var res_path = ret.datalist[i].PATH;
					            var sub_menu_id = ret.datalist[i].SUB_MENU_ID;	
					            var main_menu_name = ret.datalist[i].MAIN_MENU_NAME;
					            var notice = ret.datalist[i].NOTICE;
					            var cnt = ret.datalist[i].CNT;
					            var like_cnt = ret.datalist[i].LIKE_CNT;
					            if (cnt == null) {
					            	cnt = 0;
					            }
					            if (like_cnt == null) {
					            	like_cnt = 0;
					            }

					            var img = dir_root+'/res'+encodeURIComponent(res_path)+'/img.jpg';
					            var newimg = img.replace(/%2F/g,"/");

		                    	var li = document.createElement("li");

								var div = "<a onclick=\"window.open('play-detail.php?res_id="+res_id+"&sub_menu_id="+sub_menu_id+"','_blank')\" style='text-decoration:none;'><img src="+newimg+"><div class='introduce'><span class='title' style='color:#333;'>"+res_name+"</span><div class='typesa'> <span>"+main_menu_name+"</span><span>"+notice+"</span></div><div class='operation'><span><i class='fa fa-eye'></i>"+cnt+"</span><span><i class='fa fa-heart'></i>"+like_cnt+"</span></div></div></a>";

		                    	li.innerHTML = div;
		                    	ul.appendChild(li);//插入到div内
								}; 
		                    	ul.appendChild(div2);
			                    if (ret.datalist==false) {
			                    	document.getElementById("error").innerText ="没有更多数据了";
			                    }

		                    };
		                },
		                error: function(){
		                	$("#ajax_ret").val("请求失败");
		                }
		        });
		}	

		function getUrlPara(strName) {
			var strHref = location.href;
			var intPos = strHref.indexOf("?");
			var strRight = strHref.substr(intPos + 1);
			var arrTmp = strRight.split("&");
			for (var i = 0; i < arrTmp.length; i++) {
				var arrTemp = arrTmp[i].split("=");
				if (arrTemp[0].toUpperCase() == strName.toUpperCase())
					return arrTemp[1];
			}
			return "";
		} 
		</script>
	</body>
</html>
