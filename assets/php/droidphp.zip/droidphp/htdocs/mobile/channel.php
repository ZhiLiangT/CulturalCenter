<?php
require 'config.php';
?>

<!DOCTYPE html>
<html>
	<head>
		<meta charset="UTF-8">
		<meta name="viewport" content="width=device-width, initial-scale=1,maximum-scale=1,user-scalable=no">
		<title>频道</title>
		<link rel="stylesheet" href="css/reset.css" />
		<link rel="stylesheet" href="css/bootstrap.min.css" />
		<link rel="stylesheet" href="css/font-awesome/font-awesome.min.css" />
		<link rel="stylesheet" href="css/lcn.css" />
		<script type="text/javascript" src="js/jquery-2.1.1.min.js"></script>
	</head>

	<body>
		<div class="channel-top">频道</div>
		<div class="classific paddingbottom">
			<?php

				$channel_img_list = get_channel_img_list();
				foreach ($channel_img_list as $key => $value) {

		            $main_menu_id = $value->MAIN_MENU_ID;
		            $main_menu_name = $value->MAIN_MENU_NAME;
		            $img = $CFG->res_dirroot.'/img/apk/menu/'.$main_menu_id.'.png';
		            echo "<div>";
		            echo "<a href='channel-list.php?main_menu_id={$main_menu_id}'><img src='{$img}'/><span></span></a>";
		            echo "</div>"; 

		        }

			?>
			
		</div>
		<ul class="atroot aatroot">
			<li>
				<a href="index.php">
				<img src="img/jingan.png">
				<span>精选</span>
				</a>
			</li>
			<li>
				<a href="channel.php">
				<img src="img/pinli.png">
				<span class="zantxt">频道</span>
				</a>
			</li>
			<li>
				<a href="series.php">
				<img src="img/zhuanan.png">
				<span>专题</span>
				</a>
			</li>
			<li>
				<a href="search.php">
				<img src="img/souan.png">
				<span>搜索</span>
				</a>
			</li>
			
			<div class="clearfix"></div>
	</ul>
	</body>
	
</html>
