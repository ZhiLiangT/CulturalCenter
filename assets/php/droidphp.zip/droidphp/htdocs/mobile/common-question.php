<?php
	require 'config.php';
?>
<!DOCTYPE html>
<html>
	<head>
		<meta charset="UTF-8">
		<meta name="viewport" content="width=device-width, initial-scale=1,maximum-scale=1,user-scalable=no">
		<title>常见问题</title>
		<link rel="stylesheet" href="css/reset.css" />
		<link rel="stylesheet" href="css/bootstrap.min.css" />
		<link rel="stylesheet" href="css/font-awesome/font-awesome.min.css" />
		<link rel="stylesheet" href="css/lcn.css" />
		<script type="text/javascript" src="js/jquery-2.1.1.min.js"></script>
	</head>
	<body>
		<div style="background-color:#eee;padding-bottom:15px;">
			<div style="background-color:white;line-height:40px;padding-left:15px;color:#BBBBBB;" onclick="window.history.back();">《 返回</div>
		</div>
		
		<?php

			$res_id = get_option_value('res_id',null);

			$res_question_deatils = get_res_name_details($res_id);

			$res_name = $res_question_deatils->RES_NAME;
			$res_path = $res_question_deatils->PATH;

			$qa_text = $CFG->res_dirroot.'/res'.$res_path.'/QA.txt';
			$qa_img = $CFG->res_dirroot.'/res'.$res_path.'/QA_IMG/';

			if(!@fopen( $qa_text, 'r' )){
				echo "<div style='padding-left:10px;'>暂无问题</div>";
			}else{
				$qa_text_array = get_step_text($qa_text);
				$count_step = count($qa_text_array)/2;

				echo "<div class='commonask'>";
				echo "<img src='img/ec.png' /><span>常见问题-{$res_name}(共{$count_step}个)</span>";
				echo "</div>";

				echo "<ul class='askcontent'>";

				for($i = 0;$i < count($qa_text_array);$i = $i+2){
					$step_index = $i/2+1;
					$content_q = $qa_text_array[$i];
					$cintent_a = $qa_text_array[$i+1];
					$content_q = mb_convert_encoding($content_q, 'utf-8', 'gbk');
					$cintent_a = mb_convert_encoding($cintent_a, 'utf-8', 'gbk');
					$index_img = $qa_img.''.$step_index.'.jpg';
					
					echo "<li>";
					echo "<div class='asktitle'>";
					echo "<span>{$step_index}.</span>";
					echo "<div class='askdetail'>";
					echo "<div><img src='img/eq.png' /><span>{$content_q}</span></div>";
					echo "<div><img src='img/ea.png' /><span>{$cintent_a}</span></div>";

					if( @fopen( $index_img, 'r' ) ){ 
						echo "<div><img style='height:190px;width:80%;' src='{$index_img}' /></div>";
					} 
					echo "</div>";
					echo "<div class='clearfix'></div>";
					echo "</div>";
					echo "</li>";
				}

			}

		?>		
		
	</body>
</html>
