<?php

	require 'config.php';
?>
<!DOCTYPE html>
<html>
	<head>
		<meta charset="UTF-8">
		<meta name="viewport" content="width=device-width, initial-scale=1,maximum-scale=1,user-scalable=no">
		<title>电子教程</title>
		<link rel="stylesheet" href="css/reset.css" />
		<link rel="stylesheet" href="css/bootstrap.min.css" />
		<link rel="stylesheet" href="css/font-awesome/font-awesome.min.css" />
		<link rel="stylesheet" href="css/lcn.css" />
		<script type="text/javascript" src="js/jquery-2.1.1.min.js"></script>
	</head>
	<body>
		<div style="background-color:#eee;padding-bottom:15px;">
			<div style="background-color:white;line-height:40px;padding-left:15px;color:#666666;" onclick="window.history.back();">《 返回</div>
		</div>
		

		<?php
			
			$res_id = get_option_value('res_id',null);

			$res_details = get_res_name_details($res_id);

			$res_name = $res_details->RES_NAME;
			$res_path = $res_details->PATH;

			$step_text = $CFG->res_dirroot.'/res'.$res_path.'/STEP.txt';
			$step_img = $CFG->res_dirroot.'/res'.$res_path.'/STEP_IMG/';
			

			if(!@fopen( $step_text, 'r' )){
				echo "<div style='padding-left:10px;'>暂无相关教程</div>";
			}else{
				$step_text_array = get_step_text($step_text); 
				$count_step = count($step_text_array);

				echo "<div class='commonask'>";
				echo "<img src='img/e.png' /><span>电子教程-{$res_name}(共{$count_step}步)</span>";
				echo "</div>";

				echo "<div class='coursecontent'>";
				echo "<div class='firststep'>";

				for($i = 0;$i < $count_step;$i++){
					$step_index = $i+1;
					$content = $step_text_array[$i];
					$content = mb_convert_encoding($content, 'utf-8', 'gbk');
					$index_img = $step_img.''.$step_index.'.jpg';
					
					echo "<div class='steptop'>";
					echo "<span style='	display: inline-block;float:left;color:#ff8834;width:6%;'>{$step_index}.</span>";
					echo "<div class='stepmiddle' style='width:94%;float:right;'>";
					echo "<div> {$content}</div>";

					if( @fopen( $index_img, 'r' ) ){ 
						echo "<div><img src='{$index_img}' /></div>";
					} 
					echo "</div>";
					echo "<div class='clearfix'></div>";
					echo "</div>";
				}
				
				echo "</div>";
				echo "</div>";

			}
		?>  		 	
	  		
	</body>
</html>
