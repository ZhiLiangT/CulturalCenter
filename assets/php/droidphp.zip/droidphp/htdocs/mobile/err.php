<!DOCTYPE html>
<html>
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
	<title>出错了</title>
</head>
<script type="text/javascript">
	var i = 1;
	var intervalid;
	// intervalid = setInterval("count_down()", 1000);
	function count_down(){
		if (i == 0)	{
		window.location.href = "index.php";
		clearInterval(intervalid);
		}
		document.getElementById("show_sec_div").innerHTML = i;
		i--;
	}
</script>
<body>
	<br/>
	<div style="width:300px;margin:0 auto;">
		<h2 align="center">出错啦!</h2>
		<div style="color:#909090;">
		<?php
			if (isset($err_msg)) {
				echo "错误原因:<br/>";
				echo $err_msg;
			}else{
				echo "请先前往首页浏览其他内容！";
			}
		?>
			<br/><br/><br/>
			<!-- 页面将在 <span id='show_sec_div'>1</span> 秒后自动跳转到<a href="index.php">首页</a>！ -->
			<a href="index.php" style="color:#666;text-align:center;width:100%;">前往首页</a>
		</div>	
	</div>

</body>
</html>


