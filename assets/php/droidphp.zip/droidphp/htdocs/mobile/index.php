<?php
require 'config.php';

?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1,maximum-scale=1,user-scalable=no">
    <meta name="apple-mobile-web-app-capable" content="yes">
	<meta name="apple-mobile-web-app-status-bar-style" content="black">
    <title>首页</title>
    <link rel="stylesheet" href="css/reset.css" />
		<link rel="stylesheet" href="css/bootstrap.min.css" />
		<link rel="stylesheet" href="css/font-awesome/font-awesome.min.css" />
		<link rel="stylesheet" href="css/lcn.css" />
		<script type="text/javascript" src="js/jquery-2.1.1.min.js" ></script>
		<script type="text/javascript" src="./js/common.js"></script>
		<script type="text/javascript" src="js/mui.min.js"></script>
		<!--标准mui.css-->
		<link rel="stylesheet" href="css/mui.min.css">
		<!--App自定义的css-->
		<link rel="stylesheet" type="text/css" href="css/app.css"/>
</head>
<body id="body_index" >
	<script type="text/javascript" charset="utf-8">

		function is_dbexit(){
			$.ajax({
				timeout: 3000,
				url: host + '/dbStatus/',
				type: 'POST',
				dataType: 'jsonp',
				jsonp:"callback",
				success: function(json){
					if (json["status"] == 1) {
					}else{
						window.location = "ini/error.php?type=3";
					}
				},
				error: function(){
					window.location = "ini/error.php?type=4";
				}
			});
		}
	</script>

<?php 
	if (!is_dir($CFG->res_root)) {
		echo "<script>window.location = 'ini/error.php?type=1';</script>";
	}else{
		if(!file_exists($db_sata)){
			echo "<script>window.location = 'ini/error.php?type=2';</script>";
		}else{
			echo "<script>is_dbexit();</script>";
		}

	}

 ?>

	<div class='top-hearder'>
		<a class='active' onclick='javascript:show_select()' >精选</a>
		<a onclick='javascript:show_rank()'>浏览排行</a>
		<a onclick='javascript:show_like()'>好评榜</a>
	</div>
<div id="select">
 
<?php
	$series_list = get_series_list();
	$series_count = series_count();
	$count_series = $series_count->num;
	if ($series_list != null) {
		echo "<div id='slider' class='mui-slider' >";
		echo "<div class='mui-slider-group mui-slider-loop'>";

    	foreach ($series_list as $key => $value) {
        	$series_name = $value->SERIES_NAME;
            $series_id = $value->SERIES_ID;
            $img = $CFG->res_dirroot.'/img/apk/series/'.$value->SERIES_ID.'.png';
            if ($count_series > 4 ) {
            	if ($key == 3) {
		            echo "<div class='mui-slider-item mui-slider-item-duplicate'>";
		            echo "<a href='series-list.php?series_id={$series_id}'><img height='180px' src='{$img}'/>";
		            echo "<p class='mui-slider-title1'>{$series_name}</p>";
		            echo "</a></div>"; 
            	}
            }else{
            	if ($key == $count_series - 1) {
		            echo "<div class='mui-slider-item mui-slider-item-duplicate'>";
		            echo "<a href='series-list.php?series_id={$series_id}'><img height='180px' src='{$img}'/>";
		            echo "<p class='mui-slider-title1'>{$series_name}</p>";
		            echo "</a></div>"; 
            	}
            }
           
    	}

        foreach ($series_list as $key => $value) {
        	$series_name = $value->SERIES_NAME;
            $series_id = $value->SERIES_ID;
            $img = $CFG->res_dirroot.'/img/apk/series/'.$value->SERIES_ID.'.png';
            echo "<div class='mui-slider-item'>";
            echo "<a href='series-list.php?series_id={$series_id}'><img height='180px' src='{$img}'/>";
            echo "<p class='mui-slider-title1'>{$series_name}</p>";
            echo "</a></div>"; 

        }

    	foreach ($series_list as $key => $value) {
        	$series_name = $value->SERIES_NAME;
            $series_id = $value->SERIES_ID;
            $img = $CFG->res_dirroot.'/img/apk/series/'.$value->SERIES_ID.'.png';
            echo "<div class='mui-slider-item mui-slider-item-duplicate'>";
            echo "<a href='series-list.php?series_id={$series_id}'><img height='180px' src='{$img}'/>";
            echo "<p class='mui-slider-title1'>{$series_name}</p>";
            echo "</a></div>"; 
            if ($key == 0) break;
    	}  	

		echo "</div>";

		echo "<div class='mui-slider-indicator lcnbo'>";

		if ($count_series > 4) {
			echo "<div class='mui-indicator mui-active'></div>";
			echo "<div class='mui-indicator'></div>";
			echo "<div class='mui-indicator'></div>";
			echo "<div class='mui-indicator'></div>";
		}else{
			for ($i=0; $i < $count_series; $i++) { 
				echo "<div class='mui-indicator'></div>";
			}
		}
		echo "</div>";
		echo "</div>";	

	}

?> 	
		<div class="choose"><img src="img/icon.png" /><span>最近更新</span></div>
			<ul class="content paddingbottom" id="choose_content">
				
			<?php

				$count_res = count_res();
				$res_count = $count_res->num;
				$dir_root = $CFG->res_dirroot;

	            echo "<input type='hidden' id='res_count' value='{$res_count}'>";
	            echo "<input type='hidden' id='dir_root' value='{$dir_root}'>";

				$update_list = get_new_update_list();
				foreach ($update_list as $key => $value) {

		            $res_id = $value->RES_ID;
		            $res_name = $value->RES_NAME;
		            $res_path = $value->PATH;
		            $sub_menu_id = $value->SUB_MENU_ID;	
		            $main_menu_name = $value->MAIN_MENU_NAME;
		            $notice = $value->NOTICE;
		            $cnt = $value->CNT;
		            $like_cnt = $value->LIKE_CNT;
		            if ($cnt == null) {
		            	$cnt = 0;
		            }
		            if ($like_cnt == null) {
		            	$like_cnt = 0;
		            }
					$upd_time = $value->UPD_DATE;

					$img = $CFG->res_dirroot.'/res'.urlencode($res_path).'/img.jpg';
		            $img = str_replace("+","%20",$img);
		        	$img = str_replace("%2F","/",$img);

		            echo "<li onclick=\"window.open('play-detail.php?res_id={$res_id}&sub_menu_id={$sub_menu_id}','_blank')\">";
		            echo "<a onclick=\"window.open('play-detail.php?res_id={$res_id}&sub_menu_id={$sub_menu_id}','_blank')\" style='text-decoration:none;'>";
					echo "<img src='{$img}' />";
		            echo "<div class='models'>";
		            echo "<span class='title' style='color:#333;'>{$res_name}</span>";
		            echo "<div class='types'><span>{$main_menu_name}</span><span>{$notice}</span></div>";
		            echo "<div class='operation'><span><i class='fa fa-eye'></i>$cnt</span><span><i class='fa fa-heart'></i>$like_cnt</span></div>";
		            echo "</div>";
					echo "</a>";
		            echo "</li>";

		        }
			?> 

			</ul>
	</div>

	<div id="rank" style="display: none;" class="paddingbottom">
			<ul class="content" id="rank_content">

		<?php
				
				$cnt_list = get_cnt_list();
				foreach ($cnt_list as $key => $value) {

		            $res_id = $value->RES_ID;
		            $res_name = $value->RES_NAME;
		            $res_path = $value->PATH;
		            $sub_menu_id = $value->SUB_MENU_ID;	
		            $main_menu_name = $value->MAIN_MENU_NAME;
		            $notice = $value->NOTICE;
		            $cnt = $value->CNT;
		            $like_cnt = $value->LIKE_CNT;
		            if ($cnt == null) {
		            	$cnt = 0;
		            }
		            if ($like_cnt == null) {
		            	$like_cnt = 0;
		            }
					$upd_time = $value->UPD_DATE;

					$img = $CFG->res_dirroot.'/res'.urlencode($res_path).'/img.jpg';
		            $img = str_replace("+","%20",$img);
		        	$img = str_replace("%2F","/",$img);

		            echo "<li onclick=\"window.open('play-detail.php?res_id={$res_id}&sub_menu_id={$sub_menu_id}','_blank')\">";
		            echo "<img src='{$img}' />";
		            echo "<div class='models'>";
		            echo "<span class='title'>{$res_name}</span>";
		            echo "<div class='types'><span>{$main_menu_name}</span><span>{$notice}</span></div>";
		            echo "<div class='operation'><span><i class='fa fa-eye'></i>$cnt</span><span><i class='fa fa-heart'></i>$like_cnt</span></div>";
		            echo "</div>";
		            echo "</li>";

		        }
		?> 

			</ul>
 			<div id="rank_error" style='text-align:center;padding-bottom: 20px;'><a onclick='javascript:rank_more()'><input style="width:100%; height:40px;border-left:0px;border-right:0px;" type="button" value="加载更多"></a></div> 
	</div>

	<div id="like" style="display: none;" class="paddingbottom">
			<ul class="content" id="like_content">

		<?php
				$like_cnt_list = get_like_cnt_list($page);
				foreach ($like_cnt_list as $key => $value) {

		            $res_id = $value->RES_ID;
		            $res_name = $value->RES_NAME;
		            $res_path = $value->PATH;
		            $sub_menu_id = $value->SUB_MENU_ID;	
		            $main_menu_name = $value->MAIN_MENU_NAME;
		            $notice = $value->NOTICE;
		            $cnt = $value->CNT;
		            $like_cnt = $value->LIKE_CNT;
		            if ($cnt == null) {
		            	$cnt = 0;
		            }
		            if ($like_cnt == null) {
		            	$like_cnt = 0;
		            }
					$upd_time = $value->UPD_DATE;

					$img = $CFG->res_dirroot.'/res'.urlencode($res_path).'/img.jpg';
		            $img = str_replace("+","%20",$img);
		        	$img = str_replace("%2F","/",$img);

		            echo "<li onclick=\"window.open('play-detail.php?res_id={$res_id}&sub_menu_id={$sub_menu_id}','_blank')\">";
		            echo "<img src='{$img}' />";
		            echo "<div class='models'>";
		            echo "<span class='title'>{$res_name}</span>";
		            echo "<div class='types'><span>{$main_menu_name}</span><span>{$notice}</span></div>";
		            echo "<div class='operation'><span><i class='fa fa-eye'></i>$cnt</span><span><i class='fa fa-heart'></i>$like_cnt</span></div>";
		            echo "</div>";
		            echo "</li>";

		        }
		?> 

			</ul>
 			<div id="like_error" style='text-align:center;padding-bottom: 20px;'><a onclick='javascript:like_more()'><input style="width:100%; height:40px;border-left:0px;border-right:0px;" type="button" value="加载更多"></a></div> 
	</div>

	<script type="text/javascript" charset="utf-8">
			var slider = mui("#slider");
			slider.slider({
						interval: 2000
					}); 

			/**
			 * 上拉加载具体业务实现
			 */

			var like_count = 1;
			var rank_count = 1;
			var res_count = $("#res_count").val();
			var dir_root = $("#dir_root").val();
			var res_page = res_count/10+1;

			function like_more(){
				
			like_count++;
			        $.ajax({ 
			                url: "ajax.php?mtd=like_pull",
			                type: "post",
			                data: "page=" + like_count,
			                dataType: "json",
			                success: function(ret){
			                    if (ret.status == 'success') {
			                    	for(var i=0;i<ret.datalist.length;i++){  

									var res_id = ret.datalist[i].RES_ID;
									var res_name = ret.datalist[i].RES_NAME;
						            var res_path = ret.datalist[i].PATH;
						            var sub_menu_id = ret.datalist[i].SUB_MENU_ID;	
						            var main_menu_name = ret.datalist[i].MAIN_MENU_NAME;
						            var notice = ret.datalist[i].NOTICE;
						            var cnt = ret.datalist[i].CNT;
						            var like_cnt = ret.datalist[i].LIKE_CNT;
						            if (cnt == null) {
						            	cnt = 0;
						            }
						            if (like_cnt == null) {
						            	like_cnt = 0;
						            }

						            var img = dir_root+'/res'+encodeURIComponent(res_path)+'/img.jpg';
						            var newimg = img.replace(/%2F/g,"/");

			                    	var ul = document.getElementById("like_content");

			                    	var li = document.createElement("li");
			                    	li.setAttribute("onclick","window.open('play-detail.php?res_id="+res_id+"&sub_menu_id="+sub_menu_id+"','_blank')");

									var div = "<img src="+newimg+"><div class='models'><span class='title'>"+res_name+"</span><div class='types'> <span>"+main_menu_name+"</span><span>"+notice+"</span></div><div class='operation'><span><i class='fa fa-eye'></i>"+cnt+"</span><span><i class='fa fa-heart'></i>"+like_cnt+"</span></div></div>";

			                    	li.innerHTML = div;
			                    	ul.appendChild(li);
									}; 

				                    if (ret.datalist==false) {
				                    	document.getElementById("like_error").innerText ="没有更多数据了";
				                    }

			                    };
			                },
			                error: function(){
			                	$("#ajax_ret").val("请求失败");
			                }
			        });
			}


			function rank_more() {
				rank_count++;
			        $.ajax({ 
			                url: "ajax.php?mtd=rank_pull",
			                type: "post",
			                data: "page=" + rank_count,
			                dataType: "json",
			                success: function(ret){
			                    if (ret.status == 'success') {
			                    	for(var i=0;i<ret.datalist.length;i++){  

									var res_id = ret.datalist[i].RES_ID;
									var res_name = ret.datalist[i].RES_NAME;
						            var res_path = ret.datalist[i].PATH;
						            var sub_menu_id = ret.datalist[i].SUB_MENU_ID;	
						            var main_menu_name = ret.datalist[i].MAIN_MENU_NAME;
						            var notice = ret.datalist[i].NOTICE;
						            var cnt = ret.datalist[i].CNT;
						            var like_cnt = ret.datalist[i].LIKE_CNT;
						            if (cnt == null) {
						            	cnt = 0;
						            }
						            if (like_cnt == null) {
						            	like_cnt = 0;
						            }

						            var img = dir_root+'/res'+encodeURIComponent(res_path)+'/img.jpg';
						            var newimg = img.replace(/%2F/g,"/");

			                    	var ul = document.getElementById("rank_content");

			                    	var li = document.createElement("li");
			                    	li.setAttribute("onclick","window.open('play-detail.php?res_id="+res_id+"&sub_menu_id="+sub_menu_id+"','_blank')");

									var div = "<img src="+newimg+"><div class='models'><span class='title'>"+res_name+"</span><div class='types'> <span>"+main_menu_name+"</span><span>"+notice+"</span></div><div class='operation'><span><i class='fa fa-eye'></i>"+cnt+"</span><span><i class='fa fa-heart'></i>"+like_cnt+"</span></div></div>";

			                    	li.innerHTML = div;
			                    	ul.appendChild(li);
									}; 

				                    if (ret.datalist==false) {
				                    	document.getElementById("rank_error").innerText ="没有更多数据了";
				                    }

			                    };
			                },
			                error: function(){
			                	$("#ajax_ret").val("请求失败");
			                }
			        });
			}

	    $(document).ready(function() {
			
			$(".top-hearder a").each(function(index) {
				$(this).click(function() {
					$(".top-hearder a").removeClass("active");
					$(".top-hearder a").eq(index).addClass("active");
				});
			});
		});
			
	    var show_select = function(){
			$('#select').show();
			$('#rank').hide();
			$('#like').hide();
	    }
	    var show_rank = function(){
			$('#rank').show();
			$('#select').hide();
			$('#like').hide();
	    }
	    var show_like = function(){
			$('#like').show();
			$('#select').hide();
			$('#rank').hide();
	    }

	</script>

	<ul class="atroot aatroot">
			<li>
				<a href="index.php">
				<img src="img/jingli.png">
				<span class="zantxt">精选</span>
				</a>
			</li>
			<li>
				<a href="channel.php">
				<img src="img/pinan.png">
				<span>频道</span>
				</a>
			</li>
			<li>
				<a href="series.php">
				<img src="img/zhuanan.png">
				<span>专题</span>
				</a>
			</li>
			<li>
				<a href="search.php">
				<img src="img/souan.png">
				<span>搜索</span>
				</a>
			</li>
			
			<div class="clearfix"></div>
	</ul>
</body>
</html>