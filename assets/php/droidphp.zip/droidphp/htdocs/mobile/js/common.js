var debug = true;
var host = "http://192.168.88.100:10001";

/**
 * 自定义控制台输出
 * @param  {[type]} text [要输出的内容]
 * @return {[type]}      [无]
 */
function myLog(text){
	if(debug && text != null){
		console.log(text);
	}
}