<html>
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
	<title>登录</title>
	
<style type="text/css">
	html,body {
		width: 100%;
		padding: 0;
		margin: 0;
	}
	.btn{
		color: #fff;
        background-color: #80B600;
        cursor: pointer;
        padding: 3px 20px 4px 20px;
		width: 50%;
		height: 26px;
		border: 0;
	}
	.btn{
        color: #fff;
        height: 30px;
        font-size: 14px;
        background: #3090C7;
        text-align: center;
        border: none;
        cursor: pointer;
        padding: 3px 20px 4px 20px;
    }
    .btn:hover, .btn:focus, .btn:active, .btn:active:focus, .btn:active.focus {
        background: #F5A623;
    }
	span{
		color: #f00;
	}
	#pwd{
		height: 24px;
		line-height: 24px;
	}
</style>
<script type="text/javascript" src="js/1.8.3.min.js"></script>
<script type="text/javascript" src="js/wenhua.js"></script>
<script type="text/javascript">
	$(function(){
		$("#pwd").focus();
	});
	function login(){
		var pwd = $("#pwd").val();
		if (pwd != '') {
        $.ajax({ 
                url: "ajax.php?mtd=login_do",
                type: "post",
                data: "pwd=" + pwd,
                dataType: "json",
                success: function(ret){
                    if (ret.status == 'success') {
                    	$("#div_float_bg").css("display","block");
                    	toast('登录成功!',2,2000);
                    	setTimeout(function(){
                        	window.location.href="admin.php";
                    	},1500);
                    }else if(ret.status == 'fail'){
                    	toast('密码不正确',1,1000);
                    }
                },
                error: function(){
                	toast('请求失败！',1,2000);
                }
        });
		}else{
        	toast('请输入管理员密码!',3,1000);
        	$("#pwd").focus();
		}
	}
</script>
</head>

<body>
<div style="width:300px;margin:0 auto;" align="center">
	<br/>
	<h2 align="center">请输入管理员密码</h2>
	<form action="activate.php">
		<input id="pwd" name="pwd" type="password" maxlength="16" placeholder="密码:" onkeydown="if(event.keyCode==13) login();"><br/><br/>
		<input type="text" style="display:none;">
		<input class="btn" type="button" onclick="login();" value="登&nbsp;&nbsp;&nbsp;&nbsp;录">
	</form>
</div>
<div id="toast" style="width:100%;height:40px;top:-40px;z-index:9999;position:fixed;color:#fff;text-align:center;line-height:40px;"></div>
<div id="div_float_bg" style="display:none;position:absolute;top:0%;left:0%;width:100%;min-width:300px;height:100%;background-color:black;z-index:998;-moz-opacity:0.3;opacity:.30;filter:alpha(opacity=30);"></div>
</body>
</html>