<?php
	require 'config.php';
?>

<!DOCTYPE html>
<html>
	<head>
		<meta charset="UTF-8">
		<meta name="viewport" content="width=device-width, initial-scale=1,maximum-scale=1,user-scalable=no">
		<title>资源详情</title>
		<link rel="stylesheet" href="css/reset.css" />
		<link rel="stylesheet" href="css/bootstrap.min.css" />
		<link rel="stylesheet" href="css/font-awesome/font-awesome.min.css" />
		<link rel="stylesheet" href="css/lcn.css" />
		<script type="text/javascript" src="js/jquery-2.1.1.min.js"></script>
	</head>
	<body>

	<script type="text/javascript" charset="utf-8"> 
    //点赞-本地
    var addLikeStatus = 0 ;
    var add_like_local = function(){
    	if (addLikeStatus == 0) {
	    	addLikeStatus = 1;
	        var res_id = $("#res_id").val();
			$('.fa-heart-o').hide();
			$('.fa-heart').show();
	        $.ajax({ 
	                url: "ajax.php?mtd=like_do",
	                type: "post",
	                data: "id=" + res_id ,
	                dataType: "json",
	                success: function(ret){
	                    if (ret.status == 'success') {
							var like_cnt = ret.datalist.LIKE_CNT;
							document.getElementById('like_cnt').innerText = like_cnt+"赞";
	                    }
	                },
	                error: function(){
	                	$("#ajax_ret").val("点赞更新请求失败");
	                }
	        }); 
    	}

    }

    //下载-本地
    var addDownloadStatus = 0 ;
    var add_download_local = function(){
    	if (addDownloadStatus == 0) {
	    	addDownloadStatus = 1;
	        var res_id = $("#res_id").val();
	        $.ajax({ 
	                url: "ajax.php?mtd=download_do",
	                type: "post",
	                data: "id=" + res_id ,
	                dataType: "json",
	                success: function(ret){
	                    if (ret.status == 'success') {
							var download_cnt = ret.datalist.DOWN_CNT;
							document.getElementById('down_cnt').innerText = download_cnt+"下载";
	                    }
	                },
	                error: function(){
	                	$("#ajax_ret").val("下载文件请求失败");
	                }
	        }); 
    	}

    }

		function closeWindow(){
			window.opener=null;
			window.open('','_self');
			window.close();
			self.close();
			window.history.back();
		}

		function getUrlPara(strName) {
			var strHref = location.href;
			var intPos = strHref.indexOf("?");
			var strRight = strHref.substr(intPos + 1);
			var arrTmp = strRight.split("&");
			for (var i = 0; i < arrTmp.length; i++) {
				var arrTemp = arrTmp[i].split("=");
				if (arrTemp[0].toUpperCase() == strName.toUpperCase())
					return arrTemp[1];
			}
			return "";
		} 

		$(document).ready(function() {
			var res_index = getUrlPara("res_index");
			if (res_index == "") {
				res_index = 1;
			}
			$(".oneline a").removeClass("activec");
			$(".oneline a").eq(res_index-1).addClass("activec");
		});

	</script>
		<div style="background-color:#eee;padding-bottom:15px;">
			<div style="background-color:white;line-height:40px;padding-left:15px;color:#666666;" onclick="closeWindow();">《 返回</div>
		</div>

		<?php

			$res_id = get_option_value('res_id',null);
			$sub_menu_id = get_option_value('sub_menu_id',null);
			$res_index = get_option_value('res_index',1);

			$res_details_obj = get_res_details($res_id);
			$res_name = $res_details_obj->RES_NAME;
			$actor = $res_details_obj->ACTOR;
			$notice = $res_details_obj->NOTICE;
			$upd_time = $res_details_obj->UPD_DATE;
			$upd_time = date('Y-m-d',strtotime($upd_time));
			$caption = $res_details_obj->CAPTION;
			$type = $res_details_obj->TYPE;
			$resType = $res_details_obj->resType;

			$video_path_obj = get_video_path($res_id);
			if ($video_path_obj == '') {
				$video_path = "";
			}else{
				$video_path = urlencode($video_path_obj->PATH);
			    $video_path = str_replace("+","%20",$video_path);
				$video_url = $CFG->res_dirroot.'/res'.$video_path.'/'.$res_index.'.mp4';
				$epub_url = $CFG->res_dirroot.'/res'.$video_path.'/'.$res_index.'.epub';
				$epub_open_url = $CFG->res_dirroot.'/ext/openepub/epub.html?path='.urlencode($epub_url);
				$pdf_url = $CFG->res_dirroot.'/res'.$video_path.'/'.$res_index.'.pdf';
				$pdf_open_url = $CFG->res_dirroot.'/ext/openpdf/web/viewer.html?path='.$pdf_url;
			}	
			$log_details_obj = get_log_details($res_id);
			
			$cnt = $log_details_obj->CNT;
			if($cnt == null){
				$cnt = 0;
			}
			$like_cnt = $log_details_obj->LIKE_CNT;
			if($like_cnt == null){
				$like_cnt = 0;
			}
			$down_cnt = $log_details_obj->DOWN_CNT;
			if($down_cnt == null){
				$down_cnt = 0;
			}
			
			update_cnt($res_id, $cnt);
			echo "<input type='hidden' id='res_id' value='{$res_id}'>";
			echo "<div class='middlewrap'>";
			if ($resType=="1") {
				$download_url = $epub_url;
				echo"<iframe style=\"width:100%;height:500px;\" src=\"{$epub_open_url}\"></iframe>";
			} else {
				if ($resType=="3") {
					$download_url = $pdf_url;
					echo"<iframe style=\"width:100%;height:350px;\" src=\"{$pdf_open_url}\"></iframe>";
				} else {
					if ($resType!="2") {
						$download_url = $video_url;
						echo "<div class='videoplayer'>";
						echo "<video id=\"res_player\" src='{$video_url}' 
							style=\"width:100%;height:170px;z-index:0;\" controls=\"controls\">
							您的浏览器不支持该组件!
							</video>";
						echo "</div>"; 
					}
				}
			}

			echo "<div class='dianzan'>";
			echo "<div><i  class='fa fa-play-circle-o'></i><span>{$cnt}次播放</span></div>";
			echo "<div><a class='dianzana' id='update_like' onclick='javascript:add_like_local()' ><i class='fa fa-heart-o'></i><i class='fa fa-heart'></i></a><span id='like_cnt'>{$like_cnt}赞</span></div>";
			echo "<div><a class='download' onclick='javascript:add_download_local()' href='{$download_url}'><i class='fa fa-download'></i></a><span id='down_cnt'>{$down_cnt}下载</span></div>";
			echo "</div>";
			echo "<div class='clearfix'></div>";
			echo "</div>";
		?>

		<div class="detail-wrap">

			<div class="otherblues">
				<div class="choose"><img src="img/icon.png" /><span>剧集</span></div>
				<div class="numwrap">
					
					<?php

						$res_list = get_res_list($res_id);
						$res_num  = count($res_list);
						if ($res_list == null) {
							echo "<div style='padding-left:10px;'>暂无视频资源</div>";
						}else{
							echo "<div class='oneline'>";
							foreach ($res_list as $key => $value) {
					            $res_index = $value->RES_INDEX; 
					            echo "<a onclick=\"window.location.href='play-detail.php?res_id={$res_id}&sub_menu_id={$sub_menu_id}&res_index={$res_index}'\">{$res_index}</a>"; 
					            if($key == 5) break;
					        }
					        echo "</div>";

							echo "<div class='oneline' id='morenum' style='display:none;'>";
							foreach ($res_list as $key => $value) {
					            $res_index = $value->RES_INDEX;
					            if($key > 5 ){
					            	echo "<a onclick=\"window.location.href='play-detail.php?res_id={$res_id}&sub_menu_id={$sub_menu_id}&res_index={$res_index}'\">{$res_index}</a>";
					            }
							}
							echo "</div>";
							if ($res_num>6) {
								echo "<div class='openup' id='breakup'>";
								echo "<a class='opendown' href='javascript:;'onclick=\"$('#morenum,#breakdown').show();$('#breakup').hide();\"><span>展开</span><i class='fa fa-caret-down'></i></a>";
								echo "</div>";
								echo "<div class='openup' id='breakdown' style='display:none;'>";
								echo "<a class='closedown' href='javascript:;' onclick=\"$('#morenum,#breakdown').hide();$('#breakup').show();\"><span>折叠</span><i class='fa fa-caret-up'></i></a>";
								echo "</div>";
							}			
						}
					?>

					</div>
				</div>
				<div class="otherblues">
					<div class="choose"><img src="img/icon.png" /><span>剧情介绍</span></div>
					<div class="choosea">

					<?php
						echo "<span>名称:<span>{$res_name}</span></span>";
						echo "<span>人物:<span>{$actor}</span></span>";
						echo "<span>剧集:<span>{$notice}</span></span>";
						echo "<span>时间:<span>{$upd_time}</span></span>";
						echo "<p><span>简介:</span>{$caption}</p>";

					?>
			
					</div>
				</div>
				<div class="otherblues">
					<div class="choose"><img src="img/icon.png" /><span>相关剧集</span></div>
		<ul class="content paddingbottom">

				<?php
					$relative_res_list = get_relative_res_list($res_id, $sub_menu_id);
					if ($relative_res_list == null) {
						echo "<div style='padding-left:10px;'>暂无相关资源</div>";
					}else{
						foreach ($relative_res_list as $key => $value) {
				            $res_id_index = $value->RES_ID;
				            $res_name = $value->RES_NAME;
				            $res_path = $value->PATH;
				            $sub_menu_id = $value->SUB_MENU_ID;
				            $main_menu_name = $value->MAIN_MENU_NAME;
				            $notice = $value->NOTICE;
				            $cnt = $value->CNT;
				            $like_cnt = $value->LIKE_CNT;
				            if ($cnt == null) {
				            	$cnt = 0;
				            }
				            $like_cnt = $value->LIKE_CNT;
				            if ($like_cnt == null) {
				            	$like_cnt = 0;
				            }

							$img = $CFG->res_dirroot.'/res'.urlencode($res_path).'/img.jpg';
				            $img = str_replace("+","%20",$img);
				        	$img = str_replace("%2F","/",$img);

				            echo "<li onclick=\"window.open('play-detail.php?res_id={$res_id_index}&sub_menu_id={$sub_menu_id}','_blank')\">";
				            echo "<img src='{$img}' />";
				            echo "<div class='models'>";
				            echo "<span class='title'>{$res_name}</span>";
				            echo "<div class='types'><span>{$main_menu_name}</span><span>{$notice}</span></div>";
				            echo "<div class='operation'><span><i class='fa fa-eye'></i>$cnt</span><span><i class='fa fa-heart'></i>$like_cnt</span></div>";
				            echo "</div>";
				            echo "</li>";
							
			        	}
					}
				?>
			</ul>
				</div>
				<div class="clearfix"></div>
			</div>

			<?php
					
				if($type == 1){
					echo "<ul class='atroot batroot'>";
					echo "<li>";
					echo "<a href='electronic-course.php?res_id={$res_id}'>";
					echo "<img src='img/eko.png'>";
					echo "<span class='zantxt'>电子教程</span>";
					echo "</a>";
					echo "</li>";
					echo "<li>";
					echo "<a href='common-question.php?res_id={$res_id}'>";
					echo "<img src='img/wen.png'>";
					echo "<span class='zantxt'>常见问题</span>";
					echo "</a>";
					echo "</li>";
					echo "<div class='clearfix'></div>";
					echo "</ul>";
				}
			?>
	</body>
</html>
