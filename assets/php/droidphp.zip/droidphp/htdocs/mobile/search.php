<?php
require 'config.php';
?>

<!DOCTYPE html>
<html>
	<head>
		<meta charset="UTF-8">
		<meta name="viewport" content="width=device-width, initial-scale=1,maximum-scale=1,user-scalable=no">
		<title>搜索</title>
		<link rel="stylesheet" href="css/reset.css" />
		<link rel="stylesheet" href="css/bootstrap.min.css" />
		<link rel="stylesheet" href="css/font-awesome/font-awesome.min.css" />
		<link rel="stylesheet" href="css/lcn.css" />
		<script type="text/javascript" src="js/jquery-2.1.1.min.js"></script>
	</head>
	<body>

		<div class="search-top">
			<a id="search_img" onclick="search_img();"><img src="img/icona.png"/></a>
			<input id="search_name" type="search" onsearch="search_img();" placeholder="请输入关键字" />
		</div>

		<ul class="atroot aatroot">
			<li>
				<a href="index.php">
				<img src="img/jingan.png">
				<span>精选</span>
				</a>
			</li>
			<li>
				<a href="channel.php">
				<img src="img/pinan.png">
				<span>频道</span>
				</a>
			</li>
			<li>
				<a href="series.php">
				<img src="img/zhuanan.png">
				<span>专题</span>
				</a>
			</li>
			<li>
				<a href="search.php">
				<img src="img/souli.png">
				<span class="zantxt">搜索</span>
				</a>
			</li>
			
			<div class="clearfix"></div>
	</ul>
	<script type="text/javascript"> 	
	 	//检索
		function search_img(){
			var searchName = document.getElementById('search_name').value;
			window.location.href="search-list.php?searchName="+searchName;
		}

	</script>
	</body>
</html>
