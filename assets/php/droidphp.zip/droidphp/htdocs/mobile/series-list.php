<?php
require 'config.php';
?>

<!DOCTYPE html>
<html>
	<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1,maximum-scale=1,user-scalable=no">
    <meta name="apple-mobile-web-app-capable" content="yes">
	<meta name="apple-mobile-web-app-status-bar-style" content="black">
    <title>专题资源</title>
    <link rel="stylesheet" href="css/reset.css" />
		<link rel="stylesheet" href="css/bootstrap.min.css" />
		<link rel="stylesheet" href="css/font-awesome/font-awesome.min.css" />
		<link rel="stylesheet" href="css/lcn.css" />
		<script type="text/javascript" src="js/jquery-2.1.1.min.js" ></script>
		<!--标准mui.css-->
		<link rel="stylesheet" href="css/mui.min.css">
		<!--App自定义的css-->
		<link rel="stylesheet" type="text/css" href="css/app.css"/>
</head>
	<body>
		
		<?php

			$series_id = get_option_value('series_id',null);

			$dir_root = $CFG->res_dirroot;

            echo "<input type='hidden' id='series_id' value='{$series_id}'>";
            echo "<input type='hidden' id='dir_root' value='{$dir_root}'>";

			$series_name_obj = get_series_name($series_id);
			if ($series_name_obj == '') {
				$series_name = "";
			}else{
				$series_name = $series_name_obj->SERIES_NAME;
			}
				echo "<div class='choose achoose'>";
				echo "<img src='img/icon.png' />";
				echo "<a class='activee'><span>{$series_name}</span></a>";
				echo "</div>";

		?>
		
		<div class="paddingbottom">

			<?php

				$series_res_list = get_series_res_list($series_id);
				if ($series_res_list == null) {
					echo "<div style='padding:10px'>暂无资源</div>";
				}else{
					echo "<ul class='content' id='series_list'>";
					foreach ($series_res_list as $key => $value) {
			            $res_id = $value->RES_ID;
			            $res_name = $value->RES_NAME;
			            $res_path = $value->PATH;
			            $sub_menu_id = $value->SUB_MENU_ID;
			            $main_menu_name = $value->MAIN_MENU_NAME;
			            $notice = $value->NOTICE;
			            $cnt = $value->CNT;
			            $like_cnt = $value->LIKE_CNT;
			            if ($cnt == null) {
			            	$cnt = 0;
			            }
			            if ($like_cnt == null) {
			            	$like_cnt = 0;
			            }
						$img = $CFG->res_dirroot.'/res'.urlencode($res_path).'/img.jpg';
			            $img = str_replace("+","%20",$img);
			        	$img = str_replace("%2F","/",$img);
			        	
			            echo "<li>";
						echo "<a onclick=\"window.open('play-detail.php?res_id={$res_id}&sub_menu_id={$sub_menu_id}','_blank')\" style='text-decoration:none;'>";
			            echo "<img src='{$img}' />";
			            echo "<div class='models'>";
			            echo "<span class='title' style='color:#333;'>{$res_name}</span>";
			            echo "<div class='types'><span>{$main_menu_name}</span><span>{$notice}</span></div>";
			            echo "<div class='operation'><span><i class='fa fa-eye'></i>$cnt</span><span><i class='fa fa-heart'></i>$like_cnt</span></div>";
			            echo "</div>";
						echo "</a>";
			            echo "</li>";
			            
		        	}
		        	echo "</ul>";
		        	echo "<div id='error' style='text-align:center;padding-bottom: 20px;'><a onclick='javascript:series_list_more()'><input style='width:100%; height:40px;border-left:0px;border-right:0px;' type='button' value='加载更多'/></a></div>";
				}


			?>
			
	</div>

	<ul class="atroot aatroot">
			<li>
				<a href="index.php">
				<img src="img/jingan.png">
				<span >精选</span>
				</a>
			</li>
			<li>
				<a href="channel.php">
				<img src="img/pinan.png">
				<span>频道</span>
				</a>
			</li>
			<li>
				<a href="series.php">
				<img src="img/zhuanli.png">
				<span class="zantxt">专题</span>
				</a>
			</li>
			<li>
				<a href="search.php">
				<img src="img/souan.png">
				<span>搜索</span>
				</a>
			</li>
			
			<div class="clearfix"></div>
	</ul>
	
	<script src="js/mui.min.js"></script>
		<script type="text/javascript" charset="utf-8">
			
			$(document).ready(function() {
			$(".achoose a").each(function(index) {
				$(this).click(function() {
					$(".achoose a").removeClass("activee");
					$(".achoose a").eq(index).addClass("activee");
				});
			});
		});
		
		var count = 1;
		var series_id = $("#series_id").val();
		var dir_root = $("#dir_root").val();

		function series_list_more() {
			count++;
		        $.ajax({ 
		                url: "ajax.php?mtd=series_list_pull",
		                type: "post",
		                data: {page: count ,series_id:series_id},
		                dataType: "json",
		                success: function(ret){
		                    if (ret.status == 'success') {
		                    	//alert(JSON.stringify(ret));
		                    	for(var i=0;i<ret.datalist.length;i++){  

								var res_id = ret.datalist[i].RES_ID;
								var res_name = ret.datalist[i].RES_NAME;
					            var res_path = ret.datalist[i].PATH;
					            var sub_menu_id = ret.datalist[i].SUB_MENU_ID;	
					            var main_menu_name = ret.datalist[i].MAIN_MENU_NAME;
					            var notice = ret.datalist[i].NOTICE;
					            var cnt = ret.datalist[i].CNT;
					            var like_cnt = ret.datalist[i].LIKE_CNT;
					            if (cnt == null) {
					            	cnt = 0;
					            }
					            if (like_cnt == null) {
					            	like_cnt = 0;
					            }

					            var img = dir_root+'/res'+encodeURIComponent(res_path)+'/img.jpg';
					            var newimg = img.replace(/%2F/g,"/");

		                    	var ul = document.getElementById("series_list");
		                    	var li = document.createElement("li");
								var div = "<a onclick=\"window.open('play-detail.php?res_id="+res_id+"&sub_menu_id="+sub_menu_id+"','_blank')\" style='text-decoration:none;'><img src="+newimg+"><div class='models'><span class='title' style='color:#333;'>"+res_name+"</span><div class='types'> <span>"+main_menu_name+"</span><span>"+notice+"</span></div><div class='operation'><span><i class='fa fa-eye'></i>"+cnt+"</span><span><i class='fa fa-heart'></i>"+like_cnt+"</span></div></div></a>";

		                    	li.innerHTML = div;
		                    	ul.appendChild(li);//插入到div内
								}; 

		                    };
		                    if (ret.datalist==false) {
		                    	document.getElementById("error").innerText ="没有更多数据了";
		                    }
		                },
		                error: function(){
		                	$("#ajax_ret").val("请求失败");
		                }
		        });
		}

		</script>
	</body>
</html>
