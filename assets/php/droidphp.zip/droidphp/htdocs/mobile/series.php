<?php
require 'config.php';
?>
<!DOCTYPE html>
<html>
	<head>
		<meta charset="UTF-8">
		<meta name="viewport" content="width=device-width, initial-scale=1,maximum-scale=1,user-scalable=no">
		<title>专题</title>
		<link rel="stylesheet" href="css/reset.css" />
		<link rel="stylesheet" href="css/bootstrap.min.css" />
		<link rel="stylesheet" href="css/font-awesome/font-awesome.min.css" />
		<link rel="stylesheet" href="css/mui.min.css">
		<link rel="stylesheet" href="css/lcn.css" />
		<script type="text/javascript" src="js/jquery-2.1.1.min.js"></script>
	</head>

	<body>
		<div class="channel-top">专题</div>
		<div class='paddingbottom'>
		<div class="classific2 " id="series">

			<?php 
				$series_count = series_count();
				$count_series = $series_count->num;
				$dir_root = $CFG->res_dirroot;

				$series_list = get_all_series_list();
				if ($series_list == null) {
					echo "<div style='padding-left:10px;'>暂无专题！</div>";
				}else{
			        foreach ($series_list as $key => $value) {

			            $series_id = $value->SERIES_ID;
			            $series_name = $value->SERIES_NAME;
			            $img = $CFG->res_dirroot.'/img/apk/series/'.$value->SERIES_ID.'.png';

			            echo "<input type='hidden' id='series_count' value='{$count_series}'>";
			            echo "<input type='hidden' id='dir_root' value='{$dir_root}'>";

			            echo "<div>";
			            echo "<a href='series-list.php?series_id={$series_id}'>";
			            echo "<img src='{$img}' />"; 
			            echo "</a>";
			            echo "<span>{$series_name}</span>";
			            echo "</div>";

			        }
				}

			 ?>	
		</div>
			<div id="error" style="text-align:center;padding-bottom: 20px;"><a onclick='javascript:series_more()'><input style='width:100%; height:40px;border-left:0px;border-right:0px;' type='button' value='加载更多'/></a></div> 
		</div>
		<ul class="atroot aatroot">
			<li>
				<a href="index.php">
				<img src="img/jingan.png">
				<span>精选</span>
				</a>
			</li>
			<li>
				<a href="channel.php">
				<img src="img/pinan.png">
				<span>频道</span>
				</a>
			</li>
			<li>
				<a href="series.php">
				<img src="img/zhuanli.png">
				<span class="zantxt">专题</span>
				</a>
			</li>
			<li>
				<a href="search.php">
				<img src="img/souan.png">
				<span>搜索</span>
				</a>
			</li>
			
			<div class="clearfix"></div>
	</ul>

	<script src="js/mui.min.js"></script>
	<script type="text/javascript" charset="utf-8">

		var count = 1;
		var series_count = $("#series_count").val();
		var dir_root = $("#dir_root").val();
		var res_page = series_count/10+1;

		function series_more() {
			count++;
		        $.ajax({ 
		                url: "ajax.php?mtd=series_pull",
		                type: "post",
		                data: "page=" + count,
		                dataType: "json",
		                success: function(ret){
		                    if (ret.status == 'success') {
		                    	for(var i=0;i<ret.datalist.length;i++){  

						            var series_id = ret.datalist[i].SERIES_ID;
						            var series_name = ret.datalist[i].SERIES_NAME;
						            var img = dir_root+'/img/apk/series/'+series_id+'.png';

			                    	var div1 = document.getElementById("series");
									var div2 = document.createElement("div");//创建input
									var a = document.createElement("a");//创建input
			                    	a.setAttribute("href","series-list.php?series_id="+series_id+"");//设置type属性
			                    	var span = "<img src='"+img+"' /><span>"+series_name+"</span>";

			                    	a.innerHTML = span;
			                    	div2.appendChild(a);
			                    	div1.appendChild(div2);
								}; 
 								if (ret.datalist==false) {
		                    		document.getElementById("error").innerText ="没有更多专题了";
		                    	}

		                    };
		                },
		                error: function(){
		                	$("#ajax_ret").val("请求失败");
		                }
		        });
		}

	</script>

	</body>
	
</html>
