<?php
require 'config.php';

if (is_login()) {

}else{
	echo "<script language='javascript' type='text/javascript'>";
	echo "window.location.href='admin.php'";
	echo "</script>";
}
?>
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
	<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
	<title>后台管理</title>
	<link rel="shortcut icon" href="img/favicon.ico" />
</head>
<style type="text/css">
	body {
		text-align: center;
	}
	.container{
		width: 90%;
		margin: 0 auto;
		color: #666;
	}
	.margin_div{
		padding-top: 10px;
		font-size: 18px;
	}
	.main_div{
		font-size: 14px;
	}
	.my_btn{
		display: block;
        color: #fff;
        width: 50%;
        height: 30px;
		line-height: 30px;
        font-size: 14px;
        background: #3090C7;
        text-align: center;
        border: none;
        cursor: pointer;
        text-decoration:none;
    }
    .my_btn:hover, .my_btn:focus, .my_btn:active, .my_btn:active:focus, .my_btn:active.focus {
        background: #F5A623;
    }
	.btns{
		margin-top:30px;
	}
	.btn_top{
		text-decoration: underline;
		float:right;
		cursor:pointer;
		color:#888;	

	}
@media only screen and (min-width: 200px) and (max-width: 479px) {
	.main_div{
		width: 200px;
	}
}
</style>
<script type="text/javascript" src="js/1.8.3.min.js"></script>
<body>
<script type="text/javascript">
	//用户退出
    function logout(){
        $.ajax({ 
                url: "ajax.php?mtd=logout_do",
                type: "post",
                data: '',
                dataType: "json",
                success: function(ret){
                    if (ret.status == 'success') {
                        window.location.href="login.php";
                    }
                },
                error: function(){
                    alert('请求失败!');
                }
        });
    }

    function update_online(){
		var retValue = window.confirm('确定要进入在线资源更新吗？');
		if(retValue){
			window.location = 'admin_update_res_online.php';
		};
    }

    function update_outline(){
		var retValue = window.confirm('确定要进入离线资源更新吗？');
		if(retValue){
			window.location = 'admin_update_res_from_usb.php';
		};
    }

    function update_apk(){
		var retValue = window.confirm('确定要进入离线升级程序吗？');
		if(retValue){
			window.location = 'admin_update_apk_from_usb.php';
		};
    }


</script>

<!-- Body Wrapper -->
<div class="body-wrapper">
	<div class="container">
			<div class="margin_div">
				<a class="btn_top" onclick="logout();">退出登录</a>
				<a class="btn_top" href='index.php' target="_blank" style="margin-right:10px;">首页</a>
			</div>

			<br/><br/>
			<div class="main_div">
				<div align="center" class="btns">
					<a class="my_btn" href="admin_form_wireless_setting.php">联网设置</a><br/>
				<?php
					if (is_dir($CFG->res_root)) {
						if (file_exists($db_sata)) {
							echo "<a class='my_btn' onclick='update_online()'>在线资源更新</a><br/>
								<a class='my_btn' onclick='update_outline()'>离线资源更新</a><br/>";
						}
					}
				?>
					<a class="my_btn" onclick='update_apk()'>离线升级程序</a><br/>
					<a class="my_btn" href="admin_about_box.php">关于终端</a><br/>
				</div>

			</div>
	</div>
</div>
<!-- / Body Wrapper -->
</body>
</html>