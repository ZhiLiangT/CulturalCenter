<!DOCTYPE html>
<html lang="en">
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
	<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
	<title>在线资源更新</title>
	<link rel="shortcut icon" href="img/favicon.ico" />
	<link rel="stylesheet" type="text/css" href="./bootstrap/css/bootstrap.min.css">
	<link rel="stylesheet" type="text/css" href="./jGrowl/jquery.jgrowl.css">
</head>

<body>
	<div id="message" style="height:auto;text-align:center;line-height:40px;margin-top:20px;margin-left:6%;margin-right:6%;background:#3090C7;font-size:22px;color:#FFFFFF" >
		
	</div>

	<div style="text-align:center;padding-top:50px;" >
		<div id="progress" style="font-size:28px;color:red;"></div>
		<div id="operation" style="font-size:18px;color:#19B955;font-weight:bold"></div>
	</div>

	<div id="loading" class="modal fade" tabindex="-1" data-backdrop="static" role="dialog" aria-hidden="true" style="top:30%;">
		<div class="modal-dialog modal-sm">
			<div class="modal-content">
				<!-- {/*模态框内容 START*/}  -->
				<div id="loadingInfo" class="modal-body text-center">
					正在启动在线更新，请稍后...
				</div>
				<!-- {/*模态框内容 END*/}  -->
			</div>
		</div>
	</div>
</body>
	<script type="text/javascript" src="./js/jquery.js"></script>
	<script type="text/javascript" src="./js/common.js"></script>
	<script type="text/javascript" src="./bootstrap/js/bootstrap.min.js"></script>
	<script type="text/javascript" src="./jGrowl/jquery.jgrowl.min.js"></script>
	<script type="text/javascript">
		var progressMsg = "";
		var progressPercnt = "";
		var progressTxt = "";
		$(function(){
			showLoading(true,"正在启动在线更新，请稍后...");
			startOnline();
			setTimeout(updateOnlie, 5000);
			
		});

		function showLoading(show,info){
			if(show){
				$("#loadingInfo").html(info);
				$("#loading").modal("show");
			}else{
				$("#loading").modal("hide");
			}
		}
		function startOnline(){
			$.ajax({
					timeout: 10000,
					url: host + '/updateResOnline/',
					//url: 'json/startOnline.json',
					type: 'POST',
					dataType: 'jsonp',
					jsonp:"callback",
					success: function(json){
					},
					error: function(){
						
					}
				});
		}
		function updateOnlie(){
			$.ajax({
				url: host + '/updateResOnlineProgress/',
				type: 'POST',
				dataType: 'jsonp',
				jsonp:"callback",
				success: function(json){
					progressMsg = json["msg"];
					if (json["status"] == 2) {
						progressPercnt = json["data"]["progress"];
						progressTxt = json["data"]["operation"];
						$("#operation").text(progressTxt);
						$("#progress").text(progressPercnt + "%");
					}else{
						$("#operation").text("");
						$("#progress").text("");
					}
					$("#message").text(progressMsg);
					showLoading(false,"正在启动在线更新，请稍后...");
				},
				error: function(){
					$.jGrowl("更新进度获取失败!",{position:"center"});
					showLoading(false,"正在启动在线更新，请稍后...");
				}
			});
			setTimeout(updateOnlie, 3000);
		}

	</script>

</html>