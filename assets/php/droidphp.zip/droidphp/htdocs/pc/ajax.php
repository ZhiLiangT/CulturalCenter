<?php
require 'config.php';

define('AJAX_ERROR',   0);
define('AJAX_SUCCESS', 1);

$mtd = $_GET["mtd"];

$mtdArr = array(
	'like_do',//点赞
	'down_do',//下载
	'login_do',//管理员登录
	'logout_do',//管理员退出
);

if (in_array($mtd, $mtdArr)) {
	// 添加了异常的捕获机制
	try {
		$mtd();
	} catch (Exception $e) {
		$ret = array();
		$ret["status"] = AJAX_ERROR;// 0表示ERROR
		$ret["msg"]    = $e->getMessage();
		print_j($ret);
		exit;
	}
} else {
	$ret = array();
	$ret["status"] = AJAX_ERROR;// 0表示ERROR
	$ret["msg"]    = "method not found";
	print_j($ret);
	exit;
}

//点赞
function like_do(){
	$res_id = get_require_value('id');
	update_like_record($res_id);
	$ret = new stdClass();
	$ret->status = 'success';
	$ret->msg = $res_id;
	print_j($ret);
	exit();
}

//下载
function down_do(){
	$res_id = get_require_value('id');
	update_down_record($res_id);
	$ret = new stdClass();
	$ret->status = 'success';
	$ret->msg = $res_id;
	print_j($ret);
	exit();
}

//管理员登录
function login_do(){
	global $CFG;
	$pwd = get_require_value('pwd');
	$pwd = my_md5($pwd,16);
	$ret = new stdClass();
	if ($pwd == $CFG->password) {
		$ret->status = 'success';
		$_SESSION["cur_ssid"] = "is_login";
		$ret->login = $_SESSION["cur_ssid"];
	}else{
		$ret->status = 'fail';
	}
	print_j($ret);
	exit();
}

//管理员退出登录
function logout_do(){
	global $CFG;
	$ret = new stdClass();
	if (isset($_SESSION["cur_ssid"])) {
		unset($_SESSION["cur_ssid"]);
	}
	$ret->status = 'success';
	
	print_j($ret);
	exit();
}