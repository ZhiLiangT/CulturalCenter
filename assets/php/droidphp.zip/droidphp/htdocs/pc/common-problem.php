<?php  
	require 'config.php';

?>
<!DOCTYPE html>
<html>
	<head>
		<meta charset="utf-8" />
		<title>常见问题</title>
		<link rel="stylesheet" href="css/reset.css" />
		<link rel="stylesheet" href="css/bootstrap.min.css" />
		<link rel="stylesheet" href="css/font-awesome.min.css" />
		<link rel="stylesheet" href="css/lcn.css" />
		<script type="text/javascript" src="js/jquery-2.1.0.js"></script>
		<script type="text/javascript" src="js/bootstrap.min.js"></script>
		<script type="text/javascript" src="js/carousel.js"></script>
		<script type="text/javascript" src="js/scroll.js"></script>
	</head>
	<body>
	<?php
		require 'ini/header.php';

	?> 
	  <div class="contentwrap">
	  	<div class="questionwrap">
		<?php
			$res_id = get_option_value('res_id',null);
			$res_details_obj = get_res_details_pc($res_id);
			$res_name = $res_details_obj->RES_NAME;
			$actor = $res_details_obj->ACTOR;
			$caption = $res_details_obj->CAPTION;
			$res_path = $res_details_obj->PATH;

			$qa_text = $CFG->res_dirroot.'/res'.$res_path.'/QA.txt';
			$qa_img = $CFG->res_dirroot.'/res'.$res_path.'/QA_IMG/';

			$img = $CFG->res_dirroot.'/res'.$res_path.'/img.jpg';

			echo "<div class='questionimg'>";
			echo "<img src='{$img}' />";
			echo "</div>";
			echo "<div class='questiondetail'>";
			echo "<span>{$res_name}</span>";
			echo "<div class='choosea'>";
			echo "<span class='people'>人物:<span>{$actor}</span></span>";
			echo "<p class='introducea'><span class='people'>简介:</span>{$caption}</p>";
			echo "</div>";
			echo "</div>";
		?>
	  	  <div class="clearfix"></div>
	  	</div>
	  <div class="browerrange ">
	  		<div class="browertop blueback">
	  			<div class="browermorea">
	  				<img src="img/quenstion.png" />
	  				<span>常见问题</span>
	  			</div>
	  			
	  			<div class="clearfix"></div>
	  		</div>
	  </div>
	  <ul class="commonask">

	<?php

		if(!@fopen( $qa_text, 'r' )){
			echo "<div style='padding-left:10px;'>暂无问题</div>";
		}else{

			$qa_text_array = get_step_text($qa_text);
			$count_step = count($qa_text_array)/2;

			for($i = 0;$i < count($qa_text_array);$i = $i+2){

				$step_index = $i/2+1;
				$content_q = $qa_text_array[$i];
				$cintent_a = $qa_text_array[$i+1];
				$content_q = mb_convert_encoding($content_q, 'utf-8', 'gbk');
				$cintent_a = mb_convert_encoding($cintent_a, 'utf-8', 'gbk');
				$index_img = $qa_img.''.$step_index.'.jpg';


				echo "<li>";
				echo "<div>";
				echo "<img src='img/ask.png'  /><span>{$content_q}</span>";
				echo "</div>";
				echo "<div>";
				echo "<img src='img/answer.png'  />";
				echo "<span>{$cintent_a}<br>";
				if( @fopen( $index_img, 'r' ) ){ 
					echo "<img style='height:190px;width:320px;' src='{$index_img}'/>";
				} 
				echo "</span>";

				echo "</div>";
				echo "</li>";
				
			}

		}

	?>
	  </ul>
	  </div>
	  
		<?php
			require 'ini/footer.php';
		?>

	</body>
</html>
