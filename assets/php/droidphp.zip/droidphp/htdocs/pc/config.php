<?php
unset($CFG);
global $CFG;
$CFG = new stdClass();

$CFG->sqldebug  = false;
$CFG->sqllogdir = "D:/tmp/";

$CFG->dbhost    = 'sqlite:'.$CFG->dirroot.'/db_api.db3';

$CFG->dirroot   = dirname(__FILE__);
$CFG->sata_path = 'http://192.168.0.81';
// $CFG->password = 'ac59075b964b0715';  //密码:123
$CFG->password = '9ede5a783fd7bbf1';  //密码:fuwubao123

$CFG->res_dirroot   = 'http://192.168.88.100:9090';//资源目录所在文件系统路径
$CFG->res_wwwroot   = 'http://192.168.88.100:9090/res';//网站资源目录url
$CFG->res_root   = '/mnt/sata/box';//网站资源目录url
$db_sata   = '/mnt/sata/box/db/box_sata.db';//db路径

// $CFG->res_wwwroot   = 'http://192.168.0.81:8070/res';//网站资源目录url
// $CFG->res_dirroot   = 'http://192.168.0.81:8070';//资源目录所在文件系统路径
// $CFG->res_root   = 'D:/CouldApplyPHP/box';//网站资源目录url
// $db_sata   = 'C:\Users\yefeng\Desktop\box\db\box_sata.db';//db路径

if (is_dir($CFG->res_root)) {
	if(file_exists($db_sata)){
		$CFG->db_sata_link = new SQLite3($db_sata);
	}
}

require_once($CFG->dirroot.'/lib/core.php');
require_once($CFG->dirroot.'/lib/function.php');