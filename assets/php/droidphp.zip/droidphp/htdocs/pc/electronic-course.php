<?php  
	require 'config.php';

?>
<!DOCTYPE html>
<html>
	<head>
		<meta charset="utf-8" />
		<title>电子教程</title>
		<link rel="stylesheet" href="css/reset.css" />
		<link rel="stylesheet" href="css/bootstrap.min.css" />
		<link rel="stylesheet" href="css/font-awesome.min.css" />
		<link rel="stylesheet" href="css/lcn.css" />
		<script type="text/javascript" src="js/jquery-2.1.0.js"></script>
		<script type="text/javascript" src="js/bootstrap.min.js"></script>
		<script type="text/javascript" src="js/carousel.js"></script>
		<script type="text/javascript" src="js/scroll.js"></script>
	</head>
	<body class="body_course">
	<?php
		require 'ini/header.php';
	?>
		<div class='contentwrap'>
			<div class='elecourse'>
			<?php
				$res_id = get_option_value('res_id',null);
				$sub_menu_id = get_option_value('sub_menu_id',null);
				$res_details = get_res_name_details($res_id);

				$res_name = $res_details->RES_NAME;
				$res_path = $res_details->PATH;

				$step_text = $CFG->res_dirroot.'/res'.$res_path.'/STEP.txt';
				$step_img = $CFG->res_dirroot.'/res'.$res_path.'/STEP_IMG/';

				if(!@fopen( $step_text, 'r' )){
					echo "<div style='padding-left:10px;'>暂无相关教程</div>";
				}else{

					$step_text_array = get_step_text($step_text); 
					$count_step = count($step_text_array);
					
					echo "<div class='browertop blueback'>";
					echo "<div class='browermorea'>";
					echo "<img src='img/e.png' />";
					echo "<span>{$res_name}(共{$count_step}步)</span>";
					echo "</div>";
					echo "<div class='clearfix'></div>";
					echo "</div>";
					echo "<div class='coursecontent'>";
					
					$step_text_array = get_step_text($step_text); 
					$count_step = count($step_text_array);

					for($i = 0;$i < $count_step;$i++){
						$step_index = $i+1;
						$content = $step_text_array[$i];
						$content = mb_convert_encoding($content, 'utf-8', 'gbk');
						$index_img = $step_img.''.$step_index.'.jpg';	

						echo "<div class='positiona' style='line-height:40px;'>";
						echo "<div class='steptop'>";
						echo "<span>{$step_index}</span><span>{$content}</span>";
						echo "</div>";

						if( @fopen( $index_img, 'r' ) ){ 
							echo "<div class='dashleft'><img src='{$index_img}' /></div>";
						} 
						echo "</div>";

					}
				}
				echo "</div>";
			?>

		</div>

		
		<div class='recommend'>
			<div class='browertop blueback guheight'>
				<div class='browermorea'>
					<span>相关推荐</span>
				</div>
				<div class='clearfix'></div>
			</div>
			<ul class='coursewrap'>
			<?php
			$relative_res_list = get_relative_res_list($res_id, $sub_menu_id);
			if ($relative_res_list == null) {
				echo "<div style='padding-left:10px;'>暂无相关资源</div>";
			}else{

				foreach ($relative_res_list as $key => $value) {
		            $res_id_index = $value->RES_ID;
		            $res_name = $value->RES_NAME;
		            $res_path = $value->PATH;
		            $sub_menu_id = $value->SUB_MENU_ID;
		            $main_menu_name = $value->MAIN_MENU_NAME;
		            $notice = $value->NOTICE;
		            $cnt = $value->CNT;
		            if ($cnt == null) {
		            	$cnt = 0;
		            }
		            $like_cnt = $value->LIKE_CNT;
		            if ($like_cnt == null) {
		            	$like_cnt = 0;
		            }

		            $img = $CFG->res_dirroot.'/res'.$res_path.'/img.jpg';

		            echo "<li>";
		            echo "<a href='lecture-detail.php?res_id={$res_id_index}&sub_menu_id={$sub_menu_id}'><img src='{$img}'/></a>";
		            echo "<div>";
		            echo "<a><span class='title titlename'>{$res_name}</span></a>";
		            echo "<div class='types'><span>{$notice}</span></div>";
		            echo "<div class='operation tubiaotop'><span><i class='fa fa-eye'></i>{$cnt}</span><span><i class='fa fa-heart'></i>{$like_cnt}</span></div>";
		            echo "</div>";
		            echo "</li>";

	        	}

			}
			?>

			<div class='clearfix'></div>
			</ul>
		</div>
	</div>
	<div style="clear:both;line-height:100px;">&nbsp;</div>
	<?php
		require 'ini/footer.php';
	?>
</body>
</html>
