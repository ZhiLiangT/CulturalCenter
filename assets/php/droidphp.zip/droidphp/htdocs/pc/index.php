<?php  
	require 'config.php';

?>
<!DOCTYPE html>
<html>
	<head>
		<meta charset="utf-8"/>
		<meta name="renderer" content="webkit">
		<title>首页</title>
		<link rel="stylesheet" href="css/reset.css" />
		<link rel="stylesheet" href="css/bootstrap.min.css" />
		<link rel="stylesheet" href="css/font-awesome.min.css" />
		<link rel="stylesheet" href="css/lcn.css" />
		<script type="text/javascript" src="js/jquery-2.1.0.js"></script>
		<script type="text/javascript" src="js/bootstrap.min.js"></script>
		<script type="text/javascript" src="js/carousel.js"></script>
		<script type="text/javascript" src="js/scroll.js"></script>
	</head>
	<body id="body_index" >
	<?php
		require 'ini/header.php';
	?>
	<script type="text/javascript" charset="utf-8"> 
		$(function(){
		    $('.myscroll').myScroll({
		        speed: 60, //数值越大，速度越慢
		        rowHeight:106 //li的高度
		    });
		});

	</script>
	  <div class="contentwrap">
	  	<div class="contenttop">
	  		
	  		<div id="carousel-example-generic" class="carousel slide" data-ride="carousel">
			
				<?php
					$series_count = count_series();
					$count_series = $series_count->num;
		        	$series_list = get_series_list();
		        	echo "<ol class='carousel-indicators'>";
		        	echo "<li data-target='#carousel-example-generic' data-slide-to='0' class='active'></li>";
		        	for ($i=1; $i < $count_series ; $i++) { 
		        		if ($i == 4) {
		        			echo "<li data-target='#carousel-example-generic' data-slide-to='4'></li>";
		        			break;
		        		}
		        		echo "<li data-target='#carousel-example-generic' data-slide-to='{$i}'></li>";
		        	}

			        echo "</ol>";


			        echo "<div class='carousel-inner' role='listbox'>";

			        foreach ($series_list as $key => $value) {

			            $series_id = $value->SERIES_ID;
			            $series_name = $value->SERIES_NAME;
			            $img = $CFG->res_dirroot.'/img/apk/series/'.$value->SERIES_ID.'.png';
			            echo "<div class='item active'>";
			            echo "<a href='series-list.php?series_id={$series_id}'><img src='{$img}' alt='...'/></a>";
			            echo "</div>"; 
			            if($key == 0) break;
			        }
			        foreach ($series_list as $key => $value) {

			            $series_id = $value->SERIES_ID;
			            $series_name = $value->SERIES_NAME;
			            $img = $CFG->res_dirroot.'/img/apk/series/'.$value->SERIES_ID.'.png';
			            if($key > 0 & $key < 4){
				            echo "<div class='item'>";
				            echo "<a href='series-list.php?series_id={$series_id}'><img src='{$img}' alt='...'/></a>";
				            echo "</div>"; 
			            }

			        }

			        if (count($series_list) > 4) {
			            echo "<div class='item'>";
			            echo "<a href='series.php'><img src='img/more.png' alt='...'/></a>";
			            echo "</div>";
			        }

			        echo "</div>";

				?>
				
				<!-- Controls -->
				<a class="left carousel-control" href="#carousel-example-generic" role="button" data-slide="prev">
					<img class="glyphicon glyphicon-chevron-left" aria-hidden="true" src="img/left.png"/>
					
				</a>
				<a class="right carousel-control" href="#carousel-example-generic" role="button" data-slide="next">
					<img class="glyphicon glyphicon-chevron-right" aria-hidden="true" src="img/right.png"/>
				</a>
			</div>

	  		<div class="praiselist">
	  		 <div class="browertop">
	  			<div class="browermorea">
	  				<img src="img/hpicon.png" />
	  				<span>好评榜</span>
	  			</div>
	  			<div class="clearfix"></div>
	  		 </div>
	  		<div class="myscroll">
	  		 <ul class="haoplist">
			<?php 

				$like_cnt_list = get_like_cnt_list();
				foreach ($like_cnt_list as $key => $value) {

		            $res_id = $value->RES_ID;
		            $res_name = $value->RES_NAME;
		            $res_path = $value->PATH;
		            $sub_menu_id = $value->SUB_MENU_ID;	
		            $main_menu_name = $value->MAIN_MENU_NAME;
		            $notice = $value->NOTICE;
		            $cnt = $value->CNT;
		            if ($cnt == null) {
		            	$cnt = 0;
		            }
		            $like_cnt = $value->LIKE_CNT;
		            if ($like_cnt == null) {
		            	$like_cnt = 0;
		            }
					$upd_time = $value->UPD_DATE;

		            $img = $CFG->res_dirroot.'/res'.urlencode($res_path).'/img.jpg';
			        $img = str_replace("+","%20",$img);
			        $img = str_replace("%2F","/",$img);

		            echo "<li>";
		            echo "<a href='lecture-detail.php?res_id={$res_id}&sub_menu_id={$sub_menu_id}'><img src='{$img}'/></a>";
		            echo "<div>";
		            echo "<a><span class='title'>{$res_name}</span></a>";
		            echo "<div class='types'><span>{$notice}</span></div>";
		            echo "<div class='operation'><span><i class='fa fa-eye'></i>{$cnt}</span><span><i class='fa fa-heart'></i>{$like_cnt}</span></div>";
		            echo "</div>";
		            echo "</li>";

		        }
			?>
	  		 	
	  		 	<div class="clearfix"></div>	
	  		 </ul>
	  		 </div>
	  		</div>
	  		<div class="clearfix"></div>
	  	</div>

	  	<div class="browerrange">
	  		<div class="browertop">
	  			<div class="browermorea">
	  				<img src="img/llicon.png" />
	  				<span>浏览排行</span>
	  			</div>

	  			<div class="clearfix"></div>
	  		</div>
	  		<ul class="themostlist">


	  		<?php

				$cnt_list = get_cnt_list();
				foreach ($cnt_list as $key => $value) {

		            $res_id_index = $value->RES_ID;
		            $res_name = $value->RES_NAME;
		            $res_path = $value->PATH;
		            $sub_menu_id = $value->SUB_MENU_ID;
		            $main_menu_name = $value->MAIN_MENU_NAME;
		            $notice = $value->NOTICE;
		            $cnt = $value->CNT;
		            if ($cnt == null) {
		            	$cnt = 0;
		            }
		            $like_cnt = $value->LIKE_CNT;
		            if ($like_cnt == null) {
		            	$like_cnt = 0;
		            }

		            $img = $CFG->res_dirroot.'/res'.urlencode($res_path).'/img.jpg';
			        $img = str_replace("+","%20",$img);
			        $img = str_replace("%2F","/",$img);

		            echo "<li>";
		            echo "<a href='lecture-detail.php?res_id={$res_id_index}&sub_menu_id={$sub_menu_id}'>";
		            echo "<div class='imgwrap'><img src='{$img}'  /></div>";
		            echo "<span class='browername'>{$res_name}</span>";
		            echo "<div class='introduce'><span>{$notice}</span>";
		            echo "<div><span><i class='fa fa-eye'></i>{$cnt}</span>";
		            echo "<span><i class='fa fa-heart'></i>{$like_cnt}</span>";
		            echo "</div>";
		            echo "</div>";
		            echo "</a>";
		            echo "</li>";
		        }

	  		?>
	  			<div class="clearfix"></div>
	  		</ul>
	  	</div>

	  	<div class="browerrange">
	  		<div class="browertop">
	  			<div class="browermorea">
	  				<img src="img/zjicon.png" />
	  				<span>最新更新</span>
	  			</div>
	  			
	  			<div class="clearfix"></div>
	  		</div>
	  		<ul class="themostlist">

			<?php
				$update_list = get_new_update_list();
				foreach ($update_list as $key => $value) {

		            $res_id_index = $value->RES_ID;
		            $res_name = $value->RES_NAME;
		            $res_path = $value->PATH;
		            $sub_menu_id = $value->SUB_MENU_ID;
		            $main_menu_name = $value->MAIN_MENU_NAME;
		            $notice = $value->NOTICE;
		            $cnt = $value->CNT;
		            if ($cnt == null) {
		            	$cnt = 0;
		            }
		            $like_cnt = $value->LIKE_CNT;
		            if ($like_cnt == null) {
		            	$like_cnt = 0;
		            }

		            $img = $CFG->res_dirroot.'/res'.urlencode($res_path).'/img.jpg';
			        $img = str_replace("+","%20",$img);
			        $img = str_replace("%2F","/",$img);

		            echo "<li>";
		            echo "<a href='lecture-detail.php?res_id={$res_id_index}&sub_menu_id={$sub_menu_id}'>";
		            echo "<div class='imgwrap'><img src='{$img}'  /></div>";
		            echo "<span class='browername'>{$res_name}</span>";
		            echo "<div class='introduce'><span>{$notice}</span>";
		            echo "<div><span><i class='fa fa-eye'></i>{$cnt}</span>";
		            echo "<span><i class='fa fa-heart'></i>{$like_cnt}</span>";
		            echo "</div>";
		            echo "</div>";
		            echo "</a>";
		            echo "</li>";

		        }
			?> 
	  			<div class="clearfix"></div>
	  		</ul>
	  	</div>
	  </div>
	<?php
		require 'ini/footer.php';

	?>
	</body>
</html>
