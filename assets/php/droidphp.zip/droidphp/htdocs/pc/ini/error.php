<!DOCTYPE html>
<html>
	<head>
		<meta charset="utf-8"/>
		<title>页面发生错误</title>
		<script type="text/javascript" src="../js/jquery-2.1.0.js"></script>
	</head>
	<body>
	<script type="text/javascript" charset="utf-8"> 

		function getUrlPara(strName) {
			var strHref = location.href;
			var intPos = strHref.indexOf("?");
			var strRight = strHref.substr(intPos + 1);
			var arrTmp = strRight.split("&");
			for (var i = 0; i < arrTmp.length; i++) {
				var arrTemp = arrTmp[i].split("=");
				if (arrTemp[0].toUpperCase() == strName.toUpperCase())
					return arrTemp[1];
			}
			return "";
		} 

		$(document).ready(function(){
			var type = getUrlPara("type");
			if (type == 0) {
				$("#error_show").text("未知错误！");
			}else if (type == 1) {
				$("#error_show").text("硬盘未挂载成功，请稍后重试！");
			}else if (type == 2) {
				$("#error_show").text("资源不完整，请联系管理员！");
			}else if (type == 3) {
				$("#error_show").text("数据结构不完整，请联系管理员！");
			}else if (type == 4) {
				$("#error_show").text("后台访问出错，请稍后重试！");
			}
		})

	</script>
		<div class="error_1">
			<div style="padding-top:20%;padding-left:34%;">
				<img style="width:16%;height:16%;float:left;" src="../img/error6.jpg">
				<div style="float:left;padding-left:2%">
					<h1 style="color:red;">网页找不到了！</h1>
					<div style="font-size:16px;color:#C0C0C0;">
						<span>错误原因：</span>
						<span id="error_show"></span>
					</div>	
				</div>
			</div>
		</div>

	</body>
</html>