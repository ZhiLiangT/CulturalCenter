	<footer class="footerwrap">
	<div>
<!-- 		<span class="mybrand">
	友情链接
</span>			
<div class="mystandard">
	<span>文化馆</span>
	<span>文化馆</span>
	<span>文化馆</span>
	<span>文化馆</span>
	<span>文化馆</span>
	<span>文化馆</span>
</div> -->
	</div>
	</footer>