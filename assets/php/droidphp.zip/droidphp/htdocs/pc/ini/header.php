  <?php
  	require 'config.php';
  ?>
  <script type="text/javascript" src="./js/common.js"></script>
	<script type="text/javascript" charset="utf-8"> 	
 	//检索
		function search_img(){
			var searchName = document.getElementById('search_name').value;
			window.open("search-list.php?searchName="+searchName);	
		}

    //点赞-本地
    var addLikeStatus = 0 ;
    function add_like_local(){
    	if (addLikeStatus == 0) {
	    	addLikeStatus = 1;
	        var res_id = $("#res_id").val();
	        $('.fa-heart-o').hide();
			$('.fa-heart').show();
	        $.ajax({ 
                url: "ajax.php?mtd=like_do",
                type: "post",
                data: "id=" + res_id ,
                dataType: "json",
                success: function(ret){
                    if (ret.status == 'success') {
                    }
                },
                error: function(){
                	$("#ajax_ret").val("点赞更新请求失败");
                }
	        });
	    }

    }

    //下载-本地
    var addDownStatus = 0 ;
    function add_down_local($restype){
    	if ($restype != '1') {
    		alert("可右键点击视频播放界面，选择视频另存为下载视频！")
    	}
    	if (addDownStatus == 0) {
	    	addDownStatus = 1;
	        var res_id = $("#res_id").val();
	        $.ajax({ 
                url: "ajax.php?mtd=down_do",
                type: "post",
                data: "id=" + res_id ,
                dataType: "json",
                success: function(ret){
                    if (ret.status == 'success') {
                    }
                },
                error: function(){
                	$("#ajax_ret").val("下载请求失败");
                }
	        });
	    }

    }
	
	$(document).ready(function() {
		var cur = getUrlPara("cur");
		$(".secondnav a").removeClass("activea");
		$(".navinner a").removeClass("activea");
		if (cur > 8) {
			$(".secondnav a").eq(cur-9).addClass("activea");
		}else{
			$(".navinner a").eq(cur).addClass("activea");
		}
	});

	$(document).ready(function() {
		var sur = getUrlPara("sur");
		$(".choosela a").removeClass("activea");
		$(".choosela a").eq(sur).addClass("activea")
	});

	$(document).ready(function() {
		var res_index = getUrlPara("res_index");
		if (res_index == "") {
			res_index = 1 ;
		}
		$(".oneline a").removeClass("activec");
		$(".oneline a").eq(res_index-1).addClass("activec");
	});

	$(document).ready(function() {
		if (getUrlPara("p") == null || getUrlPara("p") == "") {
			$(".pagination a").eq(1).addClass("pageactive");
		} else{
			var p = getUrlPara("p");
			var q = p%10;
			if (q == 0) {
				q = 10 ;
			}
			$(".pagination a").removeClass("pageactive");
			$(".pagination a").eq(q).addClass("pageactive");
		}

	});

	function getUrlPara(strName) {
		var strHref = location.href;
		var intPos = strHref.indexOf("?");
		var strRight = strHref.substr(intPos + 1);
		var arrTmp = strRight.split("&");
		for (var i = 0; i < arrTmp.length; i++) {
			var arrTemp = arrTmp[i].split("=");
			if (arrTemp[0].toUpperCase() == strName.toUpperCase())
				return arrTemp[1];
		}
		return "";
	} 

	function is_dbexit(){

		$.ajax({
			timeout: 3000,
			url: host + '/dbStatus/',
			type: 'POST',
			dataType: 'jsonp',
			jsonp:"callback",
			success: function(json){
				if (json["status"] == 1) {
				}else{
					window.location = "ini/error.php?type=3";
				}
			},
			error: function(){
				window.location = "ini/error.php?type=4";
			}
		});
	}
	</script>

<?php
		if (!is_dir($CFG->res_root)) {
			header("location: ini/error.php?type=1");
		}else{
			if(!file_exists($db_sata)){
				header("location: ini/error.php?type=2");
			}else{
				echo "<script>is_dbexit();</script>";
			}

		}
?>
	<div class='bannertop'>
		<div class='bannerleft'>
				<a href='index.php'><img src='img/logo.png' /></a>
				<span>全国文化信息资源共享工程</span>
			</div>
	  	 <div class='bannerright'>
	  	 	<input id='search_name' type='search' placeholder='请输入搜索内容' />
	  	 	<a onclick='search_img();'><img src='img/search.png'/></a>
	  	 </div>
		<div class='clearfix'></div>	
	</div>

  <div class="navwrap">
  	<div class="navlist">

	<?php

		$channel_img_list = get_channel_img_list();
		$channel_count = count($channel_img_list);

		echo "<div class='navinner'>";
		echo "<a href='index.php' >首页</a>";

		foreach ($channel_img_list as $key => $value) {

            $main_menu_id = $value->MAIN_MENU_ID;
            $main_menu_name = $value->MAIN_MENU_NAME;
            $index = $key + 1;
            $img = $CFG->res_dirroot.'/img/apk/menu/'.$main_menu_id.'.png';
            echo "<a href=\"lecture-list.php?main_menu_id={$main_menu_id}&cur={$index}\">{$main_menu_name}</a>";

            if($key == 7) break;
        }

        echo "</div>";

        if ($channel_count > 8) {
			echo "<a class='morea' id='allooka'  href=\"javascript:;\" onclick=\"$('#fivemore,#getupa').show();$('#allooka').hide();\" style=\"display:block;\">更多<i class='fa fa-caret-down'></i></a>";
			echo "<a class='morea' id='getupa' href=\"javascript:;\" onclick=\"$('#fivemore,#getupa').hide();$('#allooka').show();\" style=\"display:none;\">收起<i class='fa fa-caret-up'></i></a>";
        }
		echo "<div class='secondnav' id='fivemore' style='display:none;''>";
		foreach ($channel_img_list as $key => $value) {
            $main_menu_id = $value->MAIN_MENU_ID;
            $main_menu_name = $value->MAIN_MENU_NAME;
            $index = $key + 1;
            $img = $CFG->res_dirroot.'/img/apk/menu/'.$main_menu_id.'.png';
            if($key > 7 ){
            	echo "<a href=\"lecture-list.php?main_menu_id={$main_menu_id}&cur={$index}\">{$main_menu_name}</a>";

            }
        }
		echo "</div>";

	?>
  		<div class="clearfix"></div>
  	</div>
  </div>