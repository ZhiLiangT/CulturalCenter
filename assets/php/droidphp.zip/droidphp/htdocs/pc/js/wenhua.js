/*
    信息提示
    text:要提示的内容
    level: 1-红色错误，2-绿色成功，3-蓝色提示
*/
function toast(text,level,time){
    var timeout = time == null ? 1000:time;
    switch (level) {
        case 1:
            $('#toast').css("background-color","#F66");
            break;
        case 2:
            $('#toast').css("background-color",'#0C9');
            break;
        case 3:
            $('#toast').css("background-color",'#F96');
            break;
        default:
            $('#toast').css("background-color",'#0C9');
            break;
    }
    $('#toast').html(text);
    $('#toast').css("top",'-40px');
    $('#toast').animate({top:'0'},200,
        function(){
            setTimeout(function(){
                $('#toast').animate({top:'-40px'},200);
            },timeout); 
        });

}


