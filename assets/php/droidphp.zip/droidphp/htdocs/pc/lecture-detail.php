<?php  
	require 'config.php';
?>
<!DOCTYPE html>
<html>
	<head>
		<meta charset="utf-8" http-equiv="" />
		<title>详情</title>
		<link rel="stylesheet" href="css/reset.css" />
		<link rel="stylesheet" href="css/bootstrap.min.css" />
		<link rel="stylesheet" href="css/font-awesome.min.css" />
		<link rel="stylesheet" href="css/lcn.css" />
		<script type="text/javascript" src="js/jquery-2.1.0.js"></script>
		<script type="text/javascript" src="js/bootstrap.min.js"></script>
		<script type="text/javascript" src="js/carousel.js"></script>
		
	</head>
	<body>
	<?php
		require 'ini/header.php';
	?>
	 <div class="vediowrap">
	 	<div class="vediocontent">

	 	<?php

			$res_id = get_option_value('res_id',null);
			$sub_menu_id = get_option_value('sub_menu_id',null);
			$res_index = get_option_value('res_index',1);
			$cur = get_option_value('cur', 0);

			$log_details_obj = get_log_details($res_id);
			$cnt = $log_details_obj->CNT;
			update_cnt($res_id, $cnt);

			$video_path_obj = get_video_path($res_id);
			if ($video_path_obj == '') {
				$video_path = "";
			}else{
				$video_path = urlencode($video_path_obj->PATH);
			    $video_path = str_replace("+","%20",$video_path);
				$video_url = $CFG->res_wwwroot.''.$video_path.'/'.$res_index.'.mp4';
				$epub_url = $CFG->res_wwwroot.''.$video_path.'/'.$res_index.'.epub';
				$epub_open_url = $CFG->res_dirroot.'/ext/openepub/epub.html?path='.urlencode($epub_url);
				$pdf_url = $CFG->res_wwwroot.''.$video_path.'/'.$res_index.'.pdf';
				$pdf_open_url = $CFG->res_dirroot.'/ext/openpdf/web/viewer.html?path='.$pdf_url;
			}

			$res_details_obj = get_res_details($res_id);
			$res_name = $res_details_obj->RES_NAME;
			$actor = $res_details_obj->ACTOR;
			$notice = $res_details_obj->NOTICE;
			$upd_time = $res_details_obj->UPD_DATE;
			$caption = $res_details_obj->CAPTION;
			$type = $res_details_obj->TYPE;
			$restype = $res_details_obj->resType;

			if ($restype=="1") {
				$download_url = $epub_url;
				echo"<iframe style=\"width:826px;height:450px;\" src=\"{$epub_open_url}\"></iframe>";
			} else {
				if ($restype=="3") {
					$download_url = $pdf_url;
					echo"<iframe style=\"width:826px;height:450px;\" src=\"{$pdf_open_url}\"></iframe>";
				} else {
					if ($restype!="2") {
						$download_url = $video_url;
						echo "<div class='videoplayer'>";
						echo "<video id=\"res_player\" src='{$video_url}' 
							style=\"width:826px;height:420px;\" controls=\"controls\">
							您的浏览器不支持该组件!
							</video>";
						echo "</div>";	
					}
				}
			}


			echo "<div class='vedioinfo'>";
			echo "<div class='vediotitle'>";
			echo "<span>剧集介绍</span>";
			echo "</div>";

			echo "<div class='choosea'>";
			echo "<span>名称:<span>{$res_name}</span></span>";
			echo "<span>人物:<span>{$actor}</span></span>";
			echo "<span>剧集:<span>{$notice}</span></span>";
			echo "<p><span>简介:</span>{$caption}</p>";
			echo "</div>";

			echo "<div class='zanwrap'>";
			echo "<input type='hidden' id='res_id' value='{$res_id}'>";
			echo "<a class='dianzana' onclick='javascript:add_like_local()' >";
			echo "<i class='fa fa-heart-o'></i><i class='fa fa-heart'></i>";
			echo "</a>";
			echo "<span>点赞</span>";
			if ($restype=="1") {
				echo "<a class='download' onclick='javascript:add_down_local($restype)' href='{$download_url}' >";
				echo "<i class='fa fa-download'></i>";
				echo "</a>";
				echo "<span>下载</span>";
			}else{
				echo "<a class='download' onclick='javascript:add_down_local($restype)' >";
				echo "<i class='fa fa-download'></i>";
				echo "</a>";
				echo "<span>下载</span>";
			}
			echo "</div>";

			if ($type == 1) {
				echo "<div class='buttongroup'>";
				echo "<a href='electronic-course.php?res_id={$res_id}&sub_menu_id={$sub_menu_id}&cur={$cur}'>电子教程</a>";
				echo "<a href='common-problem.php?res_id={$res_id}&&cur={$cur}'>常见问题</a>";
				echo "</div>";
			}

	 	?>
			</div>
			<div class="clearfix"></div>
	 	</div>
	 </div>
<div class="contentwrapa  padtop">
	 <div class="browerrange">
	  		<div class="browertop">
	  			<div class="browermorea">
	  				<span>剧集</span>
	  			</div>
	  			<a class="browermore" id="breakdown" style="display:none;"><i class="fa fa-caret-down"></i></a>
	  			<a class="browermore" id="breakup"><i class="fa fa-caret-up"></i></a>
	  			<div class="clearfix"></div>
	  		</div>

			<?php

				$res_list = get_res_list($res_id);

				$res_num  = count($res_list);

				if ($res_list == null) {
					echo "<div style='padding-left:10px;'>暂无视频资源</div>";
				}else{

					echo "<div class='oneline'>";
					foreach ($res_list as $key => $value) {
			            $res_index = $value->RES_INDEX; 
			            echo "<a href='lecture-detail.php?res_id={$res_id}&sub_menu_id={$sub_menu_id}&res_index={$res_index}'>{$res_index}</a>"; 
			            if($key == 17) break;
			        }
			        echo "</div>";

					echo "<div class='oneline' id='morenum'>";
					foreach ($res_list as $key => $value) {
			            $res_index = $value->RES_INDEX; 
			            if ($key > 17 ) {
			            echo "<a href='lecture-detail.php?res_id={$res_id}&sub_menu_id={$sub_menu_id}&res_index={$res_index}'>{$res_index}</a>"; 
			            }
					
			        }
					echo "</div>";
				}
			?>

	</div>
	 <div class="browerrange martop">
	  		<div class="browertop">
	  			<div class="browermorea">
	  				<span>相关剧集</span>
	  			</div>	  			
	  			<div class="clearfix"></div>
	  		</div>
	  		<ul class="themostlist">

			<?php
				$relative_res_list = get_relative_res_list($res_id, $sub_menu_id);
				if ($relative_res_list == null) {
					echo "<div style='padding-left:10px;'>暂无相关资源</div>";
				}else{
					foreach ($relative_res_list as $key => $value) {
			            $res_id_index = $value->RES_ID;
			            $res_name = $value->RES_NAME;
			            $res_path = $value->PATH;
			            $sub_menu_id = $value->SUB_MENU_ID;
			            $main_menu_name = $value->MAIN_MENU_NAME;
			            $notice = $value->NOTICE;
			            $cnt = $value->CNT;
			            if ($cnt == null) {
			            	$cnt = 0;
			            }
			            $like_cnt = $value->LIKE_CNT;
			            if ($like_cnt == null) {
			            	$like_cnt = 0;
			            }

			            $img = $CFG->res_dirroot.'/res'.urlencode($res_path).'/img.jpg';
				        $img = str_replace("+","%20",$img);
				        $img = str_replace("%2F","/",$img);

			            echo "<li>";
			            echo "<a href='lecture-detail.php?res_id={$res_id_index}&sub_menu_id={$sub_menu_id}'>";
			            echo "<div class='imgwrap'><img src='{$img}'  /></div>";
			            echo "<span class='browername'>{$res_name}</span>";
			            echo "<div class='introduce'><span>{$notice}</span>";
			            echo "<div><span><i class='fa fa-eye'></i>{$cnt}</span>";
			            echo "<span><i class='fa fa-heart'></i>{$like_cnt}</span>";
			            echo "</div>";
			            echo "</div>";
			            echo "</a>";
			            echo "</li>";
		        	}
				}
			?>

	  			<div class="clearfix"></div>
	  		</ul>
	  	</div>
	  	</div>
		<?php
			require 'ini/footer.php';

		?>
		<script type="text/javascript" charset="utf-8">
			
		//聚集缓冲
		$(document).ready(function(){
			$('#breakdown').click(function(){
				$('#breakdown').hide();
				$('#breakup').show();
				$("#morenum").hide(800);
				
				
			})
			$('#breakup').click(function(){
				$('#breakdown').show();
				$('#breakup').hide();
				$("#morenum").show(800);
			})	
	})
		</script>
	</body>
</html>