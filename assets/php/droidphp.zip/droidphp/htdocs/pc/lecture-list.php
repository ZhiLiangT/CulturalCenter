<?php  
	require 'config.php';
?>
<!DOCTYPE html>
<html>
	<head>
		<meta charset="utf-8" />
		<title>文化讲堂</title>
		<link rel="stylesheet" href="css/reset.css" />
		<link rel="stylesheet" href="css/bootstrap.min.css" />
		<link rel="stylesheet" href="css/font-awesome.min.css" />
		<link rel="stylesheet" href="css/lcn.css" />
		<script type="text/javascript" src="js/jquery-2.1.0.js"></script>
		<script type="text/javascript" src="js/bootstrap.min.js"></script>		
		
	</head>
	<body>

	<?php
		require 'ini/header.php';
	?>
	  <div class="contentwrap">
	<?php  

		$cur = get_option_value('cur',null);
		$sur = get_option_value('sur',null);
		$main_menu_id = get_option_value('main_menu_id',null);
		$sub_menu_id_at = get_option_value('sub_menu_id',null);

		$pagenum = get_option_value('p',1);
		$pagesize = get_option_value('ps',15);
		$pre_page = ($pagenum > 1) ? ($pagenum - 1) : 1;

		if ($sub_menu_id_at == null) {
			$res_num = count_by_main($main_menu_id);
		}else{
			$res_num = count_by_sub($sub_menu_id_at);
		}
		$num = $res_num->num;
		$pages = 0;
		$page_count = ceil($num/15);
		for ($i=0; $i < $num; $i=$i+15) { 
			$pages++;
		}
		$next_page = ($pagenum < $pages - 1) ? ($pagenum + 1) : $pages;

		$sub_menu_name_list = get_sub_menu_name($main_menu_id);

		if ($sub_menu_name_list == null) {
			echo "<div style='padding-left:10px;'>没有二级菜单栏目</div>";
		}else{
			echo "<div class='chooselist'>";
			echo "<span>类别：</span>";
			echo "<div class='choosela'>";
			echo "<a href=\"javascript:;\" onclick=\"window.location.href='lecture-list.php?main_menu_id={$main_menu_id}&cur={$cur}';\">全部</a>";
			foreach ($sub_menu_name_list as $key => $value) {

	            $sub_menu_name = $value->SUB_MENU_NAME;
	            $sub_menu_id = $value->SUB_MENU_ID;
	            $sur_r = $key+1;
	            echo "<a href=\"javascript:;\" onclick=\"window.location.href= 'lecture-list.php?main_menu_id={$main_menu_id}&sub_menu_id={$sub_menu_id}&cur={$cur}&sur={$sur_r}'; $('#{$sub_menu_id}').show(); $('#intangible').hide(); \">{$sub_menu_name}</a>";
		    }
			echo "</div>";
			echo "</div>";
		}

	?>
	  	<div class="browerrange">
	  		
			<?php 

			if ($sub_menu_id_at == null) {
				$sub_menu_res_list = get_sub_menu_res($main_menu_id,$pagenum,$pagesize);
			}else{
				$sub_menu_res_list = get_sub_res($sub_menu_id_at,$pagenum,$pagesize);
			}
			if ($sub_menu_res_list == null) {
				echo "<div style='padding-left:10px;'>没有相关资源</div>";
			}else{
				echo "<ul class='themostlist'>";
				foreach ($sub_menu_res_list as $key => $value) {
		            $res_id_index = $value->RES_ID;
		            $res_name = $value->RES_NAME;
		            $res_path = $value->PATH;
		            $sub_menu_id = $value->SUB_MENU_ID;
		            $main_menu_name = $value->MAIN_MENU_NAME;
		            $notice = $value->NOTICE;
		            $cnt = $value->CNT;
		            if ($cnt == null) {
		            	$cnt = 0;
		            }
		            $like_cnt = $value->LIKE_CNT;
		            if ($like_cnt == null) {
		            	$like_cnt = 0;
		            }

		            $img = $CFG->res_dirroot.'/res'.urlencode($res_path).'/img.jpg';
		            $img = str_replace("+","%20",$img);
		            $img = str_replace("%2F","/",$img);
		            echo "<li>";
		            echo "<a href='lecture-detail.php?res_id={$res_id_index}&sub_menu_id={$sub_menu_id}&cur={$cur}'>";
		            echo "<div class='imgwrap'><img src='{$img}'  /></div>";
		            echo "<span class='browername'>{$res_name}</span>";
		            echo "<div class='introduce'><span>{$notice}</span>";
		            echo "<div><span><i class='fa fa-eye'></i>{$cnt}</span>";
		            echo "<span><i class='fa fa-heart'></i>{$like_cnt}</span>";
		            echo "</div>";
		            echo "</div>";
		            echo "</a>";
		            echo "</li>";

	        	}
	        	echo "<div class='clearfix'></div>";
	        	echo "</ul>";

	        	echo "<ul class='pagination lcnpage'>";
				echo "<li>";
				echo "<a href='lecture-list.php?main_menu_id={$main_menu_id}&sub_menu_id={$sub_menu_id_at}&cur={$cur}&sur={$sur}&p={$pre_page}&ps={$pagesize}' aria-label='Previous'>";	
				echo "<span aria-hidden='true'><i class='fa fa-caret-left'></i></span>";
				echo "</a>";
				echo "</li>";
				$k = floor(($pagenum-1)/10);
				$j = $k*10;

				for ($i=$j*15; $i < $num; $i=$i+15) { 
					$j++;
					echo "<li>";
					echo "<a href='lecture-list.php?main_menu_id={$main_menu_id}&sub_menu_id={$sub_menu_id_at}&cur={$cur}&sur={$sur}&p={$j}&ps={$pagesize}'>{$j}</a>";
					echo "</li>";
					if ($j%10 == 0) break; 
				}
				echo "<li>";
				echo "<a href='lecture-list.php?main_menu_id={$main_menu_id}&sub_menu_id={$sub_menu_id_at}&cur={$cur}&sur={$sur}&p={$next_page}&ps={$pagesize}' aria-label='Next'>";
				echo "<span aria-hidden='true'><i class='fa fa-caret-right'></i></span>";
				echo "</a>";
				echo "</li>";
				echo "</ul>";

			}
			?>			
				
	  	</div>
	  </div>
	<?php
		require 'ini/footer.php';

	?>
	</body>
</html>
