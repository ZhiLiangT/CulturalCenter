<?php
if (!isset($_SESSION)) {
	session_start();
}

//获取专题名称和id
function get_series_list(){
	global $CFG;
	$query = "select 
						SERIES_ID, 
						SERIES_NAME 
				from 
						BOX_SERIES 
				order by 
						SERIES_ID DESC 
			;";

	$main_series_list = get_records_sql($query,$CFG->db_sata_link, $strict = false);
	$series_list = $main_series_list;
	
	return $series_list;
}

//获取所有专题名称和id
function get_all_series_list($pagenum,$pagesize){
	if ($pagenum <= 0) {
		$pagenum = 1;
	}
	$start_row = ($pagenum - 1) * $pagesize;
	global $CFG;
	$query = "SELECT 
						SERIES_ID, 
						SERIES_NAME 
				from 
						BOX_SERIES 
				order by 
						SERIES_ID DESC
				LIMIT {$start_row},{$pagesize}
			;";

	$main_series_list = get_records_sql($query,$CFG->db_sata_link, $strict = false);
	$series_list = $main_series_list;
	
	return $series_list;
}

//获取最近更新列表
function get_new_update_list(){
	global $CFG;
	$query = "SELECT							
					br.RES_ID,						
					br.RES_NAME,						
					br.PATH,	
					br.SUB_MENU_ID,					
					bmm.MAIN_MENU_NAME,					
					br.NOTICE,						
					bl.CNT,						
					bl.LIKE_CNT,						
					br.UPD_DATE						
				FROM							
					BOX_RES br						
				INNER JOIN BOX_SUB_MENU bsm ON br.SUB_MENU_ID = bsm.SUB_MENU_ID							
				INNER JOIN BOX_MAIN_MENU bmm ON bsm.MAIN_MENU_ID = bmm.MAIN_MENU_ID							
				LEFT JOIN BOX_LOG bl ON br.RES_ID = bl.RES_ID							
				ORDER BY							
					br.RES_ID DESC						
				LIMIT 10							
			;";
	$new_update_list = get_records_sql($query,$CFG->db_sata_link, $strict = false);

	return $new_update_list;
}
//获取浏览排行
function get_cnt_list(){
	global $CFG;
	$query = "SELECT								
					br.RES_ID,							
					br.RES_NAME,							
					br.PATH,
					br.SUB_MENU_ID,								
					bmm.MAIN_MENU_NAME,							
					br.NOTICE,							
					bl.CNT,							
					bl.LIKE_CNT,							
					br.UPD_DATE							
				FROM								
					BOX_RES br							
				INNER JOIN 
					BOX_SUB_MENU bsm ON br.SUB_MENU_ID = bsm.SUB_MENU_ID				
				INNER JOIN 
					BOX_MAIN_MENU bmm ON bsm.MAIN_MENU_ID = bmm.MAIN_MENU_ID
				LEFT JOIN 
					BOX_LOG bl ON br.RES_ID = bl.RES_ID							
				ORDER BY								
					 bl.CNT DESC							
				LIMIT 10		
		;";
	$cnt_list = get_records_sql($query,$CFG->db_sata_link, $strict = false);

	return $cnt_list;
}
//获取好评榜
function get_like_cnt_list(){
	global $CFG;
	$query = "SELECT								
					br.RES_ID,							
					br.RES_NAME,							
					br.PATH,	
					br.SUB_MENU_ID,							
					bmm.MAIN_MENU_NAME,							
					br.NOTICE,							
					bl.CNT,							
					bl.LIKE_CNT,							
					br.UPD_DATE							
				FROM								
					BOX_RES br							
				INNER JOIN 
					BOX_SUB_MENU bsm ON br.SUB_MENU_ID = bsm.SUB_MENU_ID
				INNER JOIN 
					BOX_MAIN_MENU bmm ON bsm.MAIN_MENU_ID = bmm.MAIN_MENU_ID
				LEFT JOIN 
					BOX_LOG bl ON br.RES_ID = bl.RES_ID							
				ORDER BY								
					 bl.LIKE_CNT DESC							
				LIMIT 10								
		;";
	$like_cnt_list = get_records_sql($query,$CFG->db_sata_link, $strict = false);

	return $like_cnt_list;
}

//根据专题id获取专题名称
function get_series_name($series_id){
	global $CFG;
	$query = "SELECT 
					SERIES_NAME 
				FROM 
					BOX_SERIES 
				WHERE 
					SERIES_ID = {$series_id}
			;";
	$series_name = get_record_sql($query, $CFG->db_sata_link, $strict = false);

	if($series_name == null){
		$series_name = '';
	}
	return $series_name;
}

//根据专题id获取专题资源列表
function get_series_res_list($series_id,$pagenum,$pagesize){
	if ($pagenum <= 0) {
		$pagenum = 1;
	}
	$start_row = ($pagenum - 1) * $pagesize;
	global $CFG;
	$query = "SELECT	
					br.RES_ID,
					br.RES_NAME,
					br.PATH,
					br.SUB_MENU_ID,	
					bmm.MAIN_MENU_NAME,
					br.NOTICE,
					bl.CNT,
					bl.LIKE_CNT
				FROM	
					BOX_SERIES bs
				INNER JOIN BOX_SERIES_RES bsr ON bs.SERIES_ID = bsr.SERIES_ID
				INNER JOIN BOX_RES br ON bsr.RES_ID = br.RES_ID
				INNER JOIN BOX_SUB_MENU bsm ON br.SUB_MENU_ID = bsm.SUB_MENU_ID
				INNER JOIN BOX_MAIN_MENU bmm ON bsm.MAIN_MENU_ID = bmm.MAIN_MENU_ID
				LEFT JOIN BOX_LOG bl ON br.RES_ID = bl.RES_ID
				WHERE	
					bs.SERIES_ID = {$series_id}
				ORDER BY	
					br.RES_ID DESC	
				LIMIT {$start_row},{$pagesize}

		;";
	$series_res_list = get_records_sql($query,$CFG->db_sata_link, $strict = false);

	return $series_res_list;
}

//根据资源id获取视频的路径

function get_video_path($res_id){
	global $CFG;
	$query = "SELECT 
					PATH 
				FROM 
					BOX_RES 
				WHERE 
					RES_ID = {$res_id}							
		;";

	$video_path_obj = get_record_sql($query,$CFG->db_sata_link, $strict = false);
	return $video_path_obj;

}

//根据资源id获取视频点击量和点赞数

function get_log_details($res_id){
	global $CFG;
	$query = "SELECT 
					CNT, 
					LIKE_CNT 
				FROM 
					BOX_LOG 
				WHERE 
					RES_ID = {$res_id}						
		;";

	$log_details_obj = get_record_sql($query,$CFG->db_sata_link, $strict = false);
	return $log_details_obj;

}

//详情页面刷新 播放量自动加1
function update_cnt($res_id, $cnt){

	global $CFG;
	$query = "SELECT 
					count(RES_ID) AS num 
				FROM 
					BOX_LOG 
				WHERE 
					RES_ID = {$res_id}						
		;";
	$num = get_record_sql($query,$CFG->db_sata_link, $strict = false);
	$cnt_db = $num ->num;

	$table_name = 'BOX_LOG';
	$update_arr = array();
	$where_arr = array();

	$insert_arr = array();
	$insert_arr['RES_ID'] = $res_id;
	$insert_arr['CNT'] = 1;
	$insert_arr['FLG'] = 1;

	$update_arr['CNT'] = $cnt + 1;
	$update_arr['FLG'] = 1;
	$where_arr['RES_ID'] = $res_id;

	if ($cnt_db == 0) {
		$result = insert($table_name, $insert_arr, $CFG->db_sata_link, $isReturnId = false);
	}else{
		update($table_name, $update_arr, $where_arr, $CFG->db_sata_link);
	}

}

//点赞
function update_like_cnt($res_id, $like_cnt){
	global $CFG;
	$table_name = 'BOX_LOG';
	$update_arr = array();
	$where_arr = array();

	$update_arr['LIKE_CNT'] = $like_cnt + 1;
	$where_arr['RES_ID'] = $res_id;

	update($table_name, $update_arr, $where_arr, $CFG->db_sata_link);
}

//获取剧集列表
function get_res_list($res_id){
	global $CFG;
		$query = "SELECT
						RES_INDEX
					FROM
						BOX_RES_LIST
					WHERE
						RES_ID = {$res_id}
					ORDER BY
						RES_INDEX ASC							
		;";
	$res_list = get_records_sql($query,$CFG->db_sata_link, $strict = false);

	return $res_list;

}

// 根据资源id获取资源详情

function get_res_details($res_id){
	global $CFG;
	$query = "SELECT
					br.RES_NAME,
					br.ACTOR,
					br.NOTICE,
					br.UPD_DATE,
					br.CAPTION,
					bmm.TYPE,
					br.TYPE as resType
				FROM
					BOX_RES br
				INNER JOIN BOX_SUB_MENU bsm ON br.SUB_MENU_ID = bsm.SUB_MENU_ID
				INNER JOIN BOX_MAIN_MENU bmm ON bmm.MAIN_MENU_ID = bsm.MAIN_MENU_ID
				WHERE
					RES_ID = {$res_id}						
		;";

	$res_details_obj = get_record_sql($query,$CFG->db_sata_link, $strict = false);
	return $res_details_obj;
}

// 根据资源id获取资源详情,pc专用

function get_res_details_pc($res_id){
	global $CFG;
	$query = "SELECT
					RES_NAME,
					ACTOR,
					CAPTION,
					PATH
				FROM
					BOX_RES
				WHERE
					RES_ID = {$res_id}					
		;";

	$res_details_obj = get_record_sql($query,$CFG->db_sata_link, $strict = false);
	return $res_details_obj;
}

// 根据资源id获取相关资源列表
function get_relative_res_list($res_id, $sub_menu_id){
	global $CFG;
	$query = "SELECT							
					br.RES_ID,						
					br.RES_NAME,						
					br.PATH,
					br.SUB_MENU_ID,
					bmm.MAIN_MENU_NAME,						
					br.NOTICE,						
					bl.CNT,						
					bl.LIKE_CNT,						
					br.UPD_DATE						
				FROM							
					BOX_SUB_MENU bsm						
				INNER JOIN BOX_MAIN_MENU bmm ON bsm.MAIN_MENU_ID = bmm.MAIN_MENU_ID		
				INNER JOIN BOX_RES br ON bsm.SUB_MENU_ID = br.SUB_MENU_ID					
				LEFT JOIN BOX_LOG bl ON br.RES_ID = bl.RES_ID						
				WHERE							
					bsm.SUB_MENU_ID = {$sub_menu_id}						
					AND br.RES_ID != {$res_id}				
				ORDER BY							
					br.RES_ID DESC						
				LIMIT 5									
		;";
	$relative_res_list = get_records_sql($query, $CFG->db_sata_link, $strict = false);
	
	return $relative_res_list;

}

//获取频道图片列表

function get_channel_img_list(){
	global $CFG;
	$query = "SELECT 
					MAIN_MENU_ID, 
					MAIN_MENU_NAME 
				FROM 
					BOX_MAIN_MENU 
				ORDER BY 
					SHOW_SORT
			;";

	$main_menu_list = get_records_sql($query,$CFG->db_sata_link, $strict = false);
	
	return $main_menu_list;

}

// 根据大分类id获取二级菜单名称

function get_sub_menu_name($main_menu_id){
	global $CFG;
	$query = "SELECT
					SUB_MENU_NAME,
					SUB_MENU_ID
				FROM
					BOX_SUB_MENU
				WHERE
					MAIN_MENU_ID = {$main_menu_id}
		;";

	$sub_menu_list = get_records_sql($query,$CFG->db_sata_link, $strict = false);
	
	return $sub_menu_list;
}

//获取搜索结果

function get_search_res_list($searchName,$pagenum,$pagesize){
	if ($pagenum <= 0) {
		$pagenum = 1;
	}
	$start_row = ($pagenum - 1) * $pagesize;	
	global $CFG;
	$query = "SELECT								
					br.RES_ID,							
					br.RES_NAME,							
					br.PATH,	
					br.SUB_MENU_ID,						
					bmm.MAIN_MENU_NAME,							
					br.NOTICE,							
					bl.CNT,							
					bl.LIKE_CNT,							
					br.UPD_DATE							
				FROM								
					BOX_RES br							
				INNER JOIN BOX_SUB_MENU bsm ON br.SUB_MENU_ID = bsm.SUB_MENU_ID			
				INNER JOIN BOX_MAIN_MENU bmm ON bsm.MAIN_MENU_ID = bmm.MAIN_MENU_ID			
				LEFT JOIN BOX_LOG bl ON br.RES_ID = bl.RES_ID							
				WHERE								
					br.RES_NAME LIKE '%{$searchName}%'							
				ORDER BY								
					bl.RES_ID DESC							
				LIMIT {$start_row},{$pagesize}								
		;";
	$search_res_list = get_records_sql($query, $CFG->db_sata_link, $strict = false);
	
	return $search_res_list;
}

//获取一级菜单全部资源列表

function get_sub_menu_res($main_menu_id,$pagenum,$pagesize){
	if ($pagenum <= 0) {
		$pagenum = 1;
	}
	$start_row = ($pagenum - 1) * $pagesize;
	global $CFG;
	$query = "SELECT	
					BOX_RES.RES_ID,					
					BOX_RES.RES_NAME,		
					BOX_RES.SUB_MENU_ID,
					BOX_MAIN_MENU.MAIN_MENU_NAME,					
					BOX_RES.PATH,					
					BOX_RES.NOTICE,					
					BOX_LOG.CNT,					
					BOX_LOG.LIKE_CNT					
				FROM						
					BOX_MAIN_MENU					
				INNER JOIN BOX_SUB_MENU ON BOX_MAIN_MENU.MAIN_MENU_ID = BOX_SUB_MENU.MAIN_MENU_ID						
				INNER JOIN BOX_RES ON BOX_SUB_MENU.SUB_MENU_ID = BOX_RES.SUB_MENU_ID		
				LEFT JOIN BOX_LOG ON BOX_RES.RES_ID = BOX_LOG.RES_ID						
				WHERE						
					BOX_MAIN_MENU.MAIN_MENU_ID = {$main_menu_id}					
				ORDER BY						
					BOX_RES.RES_ID DESC					
				LIMIT {$start_row},{$pagesize}					
		;";
	$sub_menu_res_list = get_records_sql($query, $CFG->db_sata_link, $strict = false);
	
	return $sub_menu_res_list;
}

//获取二级菜单全部资源列表
function get_sub_res($sub_menu_id,$pagenum,$pagesize){
	if ($pagenum <= 0) {
		$pagenum = 1;
	}
	$start_row = ($pagenum - 1) * $pagesize;
	global $CFG;
	$query = "SELECT							
					br.RES_ID,						
					br.RES_NAME,						
					br.PATH,		
					br.SUB_MENU_ID,
					bmm.MAIN_MENU_NAME,						
					br.NOTICE,						
					bl.CNT,						
					bl.LIKE_CNT,						
					br.UPD_DATE						
				FROM							
					BOX_RES br						
				INNER JOIN BOX_SUB_MENU bsm ON br.SUB_MENU_ID = bsm.SUB_MENU_ID				
				INNER JOIN BOX_MAIN_MENU bmm ON bsm.MAIN_MENU_ID = bmm.MAIN_MENU_ID			
				LEFT JOIN BOX_LOG bl ON br.RES_ID = bl.RES_ID							
				WHERE							
					bsm.SUB_MENU_ID = {$sub_menu_id}					
				ORDER BY							
					bl.CNT DESC						
				LIMIT {$start_row},{$pagesize}					
		;";
	$sub_res_list = get_records_sql($query, $CFG->db_sata_link, $strict = false);
	
	return $sub_res_list;
}

//根据资源id获取资源名称和资源路径

function get_res_name_details($res_id){
	global $CFG;
	$query = "SELECT
					RES_NAME,
					PATH
				FROM
					BOX_RES
				WHERE
					RES_ID = {$res_id}				
		;";

	$res_name_details = get_record_sql($query,$CFG->db_sata_link, $strict = false);
	return $res_name_details;

}

//读取step_txt文件内容

function get_step_text($step_text){
	$txt = fopen("{$step_text}", "r");
	$step_array = array();
	$i = 0;
	//输出文本中所有的行，直到文件结束为止。
	while(! feof($txt))
	{
	 $step_array[$i] = fgets($txt);//fgets()函数从文件指针中读取一行
	 $i++;
	}
	fclose($txt);
	$step_array = array_filter($step_array);
	return $step_array;
}

//根据一级菜单获取资源count数

function count_by_main($main_menu_id){
	global $CFG;
	$query = "SELECT
					count(BOX_RES.RES_ID) AS num
				FROM
					BOX_MAIN_MENU
				INNER JOIN BOX_SUB_MENU ON BOX_MAIN_MENU.MAIN_MENU_ID = BOX_SUB_MENU.MAIN_MENU_ID
				INNER JOIN BOX_RES ON BOX_SUB_MENU.SUB_MENU_ID = BOX_RES.SUB_MENU_ID
				WHERE
					BOX_MAIN_MENU.MAIN_MENU_ID = {$main_menu_id}				
		;";
	$main_num = get_record_sql($query, $CFG->db_sata_link, $strict = false);
	
	return $main_num;
}

//根据二级菜单获取资源count数

function count_by_sub($sub_menu_id){
	global $CFG;
	$query = "SELECT
					count(br.RES_ID) AS num
				FROM
					BOX_RES br
				INNER JOIN BOX_SUB_MENU bsm ON br.SUB_MENU_ID = bsm.SUB_MENU_ID
				WHERE
					bsm.SUB_MENU_ID = {$sub_menu_id}				
		;";
	$sub_num = get_record_sql($query, $CFG->db_sata_link, $strict = false);
	
	return $sub_num;
}

//根据专题id获取资源count数

function count_by_series($series_id){
	global $CFG;
	$query = "SELECT
					count(br.RES_ID) AS num
				FROM
					BOX_SERIES bs
				INNER JOIN BOX_SERIES_RES bsr ON bs.SERIES_ID = bsr.SERIES_ID
				INNER JOIN BOX_RES br ON bsr.RES_ID = br.RES_ID
				WHERE
					bs.SERIES_ID = {$series_id}		
		;";
	$series_num = get_record_sql($query, $CFG->db_sata_link, $strict = false);
	
	return $series_num;
}

//获取搜索总数

function count_by_searchName($searchName){
	global $CFG;
	$query = "SELECT
					count(RES_ID) as num
				FROM
					BOX_RES
				WHERE
					RES_NAME LIKE '%{$searchName}%'
				ORDER BY
					RES_ID DESC					
		;";
	$search_count = get_record_sql($query, $CFG->db_sata_link, $strict = false);
	
	return $search_count;	
}

//获取专题总数

function count_series(){
	global $CFG;
	$query = "SELECT
					count(SERIES_ID) AS num
				FROM
					BOX_SERIES 	
		;";

	$series_num = get_record_sql($query, $CFG->db_sata_link, $strict = false);
	
	return $series_num;
}

//更新点赞次数
function update_like_record($res_id){
	global $CFG;
	if($res_id != null){
		//更新点赞次数
		$table_name = 'BOX_LOG';
		$insert_arr = array();
		$where_arr = array();
		$update_arr = array();

		$insert_arr['RES_ID'] = $res_id;
		$insert_arr['LIKE_CNT'] = 1;

		$where_arr['RES_ID'] = $res_id;

		$query_record = array();
		$query = "SELECT 
					RES_ID,
					LIKE_CNT
				FROM
					{$table_name}
				WHERE
					RES_ID='{$res_id}';";
		$query_record = get_record_sql($query, $CFG->db_sata_link, $strict = false);
		if($query_record != null){
			$update_arr['LIKE_CNT'] = $query_record->LIKE_CNT + 1;
			
			$result = update($table_name, $update_arr, $where_arr, $CFG->db_sata_link);
		}else{
			$result = insert($table_name, $insert_arr, $CFG->db_sata_link, $isReturnId = false);
		}
	}
}

//更新下载次数
function update_down_record($res_id){
	global $CFG;
	if($res_id != null){
		$table_name = 'BOX_LOG';
		$insert_arr = array();
		$where_arr = array();
		$update_arr = array();

		$insert_arr['RES_ID'] = $res_id;
		$insert_arr['DOWN_CNT'] = 1;

		$where_arr['RES_ID'] = $res_id;

		$query_record = array();
		$query = "SELECT 
					RES_ID,
					DOWN_CNT
				FROM
					{$table_name}
				WHERE
					RES_ID='{$res_id}';";
		$query_record = get_record_sql($query, $CFG->db_sata_link, $strict = false);
		if($query_record != null){
			$update_arr['DOWN_CNT'] = $query_record->DOWN_CNT + 1;
			
			$result = update($table_name, $update_arr, $where_arr, $CFG->db_sata_link);
		}else{
			$result = insert($table_name, $insert_arr, $CFG->db_sata_link, $isReturnId = false);
		}
	}
}

//管理员是否已经登录
function is_login(){
	if (isset($_SESSION["cur_ssid"])) {
		return true;
	}else{
		return false;
	}
}
