<?php  
	require 'config.php';

?>
<!DOCTYPE html>
<html>
	<head>
		<meta charset="utf-8" />
		<title>专题列表</title>
		<link rel="stylesheet" href="css/reset.css" />
		<link rel="stylesheet" href="css/bootstrap.min.css" />
		<link rel="stylesheet" href="css/font-awesome.min.css" />
		<link rel="stylesheet" href="css/lcn.css" />
		<script type="text/javascript" src="js/jquery-2.1.0.js"></script>
		<script type="text/javascript" src="js/bootstrap.min.js"></script>		
		
	</head>
	<body>
	<?php
		require 'ini/header.php';

	?>
	  <div class="contentwrap padtop">
	  	<div class="browerrange">
		<?php

			$series_id = get_option_value('series_id',null);
			$pagenum = get_option_value('p',1);
			$pagesize = get_option_value('ps',15);
			$pre_page = ($pagenum > 1) ? ($pagenum - 1) : 1;

			$series_num = count_by_series($series_id);
			$num = $series_num->num;
			$pages = 0;
			for ($i=0; $i < $num; $i=$i+15) { 
				$pages++;
			}
			
			$next_page = ($pagenum < $pages - 1) ? ($pagenum + 1) : $pages;

			$series_res_list = get_series_res_list($series_id,$pagenum,$pagesize);
			if ($series_res_list == null) {
				echo "<div style='padding-left:10px;'>暂无资源</div>";
			}else{
				echo "<ul class='themostlist'>";
				foreach ($series_res_list as $key => $value) {
		            $res_id = $value->RES_ID;
		            $res_name = $value->RES_NAME;
		            $res_path = $value->PATH;
		            $sub_menu_id = $value->SUB_MENU_ID;
		            $main_menu_name = $value->MAIN_MENU_NAME;
		            $notice = $value->NOTICE;
		            $cnt = $value->CNT;
		            if ($cnt == null) {
		            	$cnt = 0;
		            }
		            $like_cnt = $value->LIKE_CNT;
		            if ($like_cnt == null) {
		            	$like_cnt = 0;
		            }

		            $img = $CFG->res_dirroot.'/res'.urlencode($res_path).'/img.jpg';
			        $img = str_replace("+","%20",$img);
			        $img = str_replace("%2F","/",$img);

		            echo "<li>";
		            echo "<a href=\"lecture-detail.php?res_id={$res_id}&sub_menu_id={$sub_menu_id}\">";
		            echo "<div class='imgwrap'><img src='{$img}'  /></div>";
		            echo "<span class='browername'>{$res_name}</span>";
		            echo "<div class='introduce'><span>{$notice}</span>";
		            echo "<div><span><i class='fa fa-eye'></i>{$cnt}</span>";
		            echo "<span><i class='fa fa-heart'></i>{$like_cnt}</span>";
		            echo "</div>";
		            echo "</div>";
		            echo "</a>";
		            echo "</li>";

	        	}
	        	echo "<div class='clearfix'></div>";
	        	echo "</ul>";
	        	echo "<ul class='pagination lcnpage'>";
				echo "<li>";
				echo "<a href='series-list.php?series_id={$series_id}&p={$pre_page}&ps={$pagesize}' aria-label='Previous'>";
				echo "<span aria-hidden='true'><i class='fa fa-caret-left'></i></span>";
				echo "</a>";
				echo "</li>";

				$k = floor(($pagenum-1)/10);
				$j = $k*10;
				for ($i=$j*15; $i < $num; $i=$i+15) { 
					$j++;
					echo "<li>";
					echo "<a href='series-list.php?series_id={$series_id}&p={$j}&ps={$pagesize}'>{$j}</a>";
					echo "</li>";
					if ($j%10 == 0) break; 
				}

				echo "<li>";
				echo "<a href='series-list.php?series_id={$series_id}&p={$next_page}&ps={$pagesize}' aria-label='Next'>";
				echo "<span aria-hidden='true'><i class='fa fa-caret-right'></i></span>";
				echo "</a>";
				echo "</li>";
				echo "</ul>";
			}
	  	?>
				
	  	</div>
	  </div>
	<?php
		require 'ini/footer.php';
	?>

	</body>
</html>
