<?php  
	require 'config.php';

?>
<!DOCTYPE html>
<html>
	<head>
		<meta charset="utf-8" />
		<title>专题</title>
		<link rel="stylesheet" href="css/reset.css" />
		<link rel="stylesheet" href="css/bootstrap.min.css" />
		<link rel="stylesheet" href="css/font-awesome.min.css" />
		<link rel="stylesheet" href="css/lcn.css" />
		<script type="text/javascript" src="js/jquery-2.1.0.js"></script>
		<script type="text/javascript" src="js/bootstrap.min.js"></script>		
		
	</head>
	<body>

	<?php
		require 'ini/header.php';

	?>
	  <div class="contentwrap padtop">
	  	<div class="browerrange">
	  		<ul class="themostlist">

	  		<?php

				$pagenum = get_option_value('p',1);
				$pagesize = get_option_value('ps',10);
				$pre_page = ($pagenum > 1) ? ($pagenum - 1) : 1;

				$series_count = count_series();
				$num = $series_count->num;
				$pages = 0;
				for ($i=0; $i < $num; $i=$i+10) { 
					$pages++;
				}
				
				$next_page = ($pagenum < $pages - 1) ? ($pagenum + 1) : $pages;
	
				$series_list = get_all_series_list($pagenum,$pagesize);

		        foreach ($series_list as $key => $value) {

		            $series_id = $value->SERIES_ID;
		            $series_name = $value->SERIES_NAME;
		            $img = $CFG->res_dirroot.'/img/apk/series/'.$value->SERIES_ID.'.png';

					
					echo "<li>";
					echo "<a href=\"series-list.php?series_id={$series_id}\">";
					echo "<div class='imgwrap'><img src='{$img}'  /></div>";
					echo "<span class='browername'>{$series_name}</span>";
					echo "</a>";
					echo "</li>";
		        }

	  		?>

	  			<div class="clearfix"></div>
	  		</ul>
	  		<ul class="pagination lcnpage">
			<?php

				echo "<li>";
				echo "<a href='series.php?p={$pre_page}&ps={$pagesize}' aria-label='Previous'>";
				echo "<span aria-hidden='true'><i class='fa fa-caret-left'></i></span>";
				echo "</a>";
				echo "</li>";

				$j = 0;
				for ($i=0; $i < $num; $i=$i+10) { 
					$j++;

					echo "<li>";
					echo "<a href='series.php?p={$j}&ps={$pagesize}'>{$j}</a>";
					echo "</li>";
				}

				echo "<li>";
				echo "<a href='series.php?p={$next_page}&ps={$pagesize}' aria-label='Next'>";
				echo "<span aria-hidden='true'><i class='fa fa-caret-right'></i></span>";
				echo "</a>";
				echo "</li>";

			  ?>

			</ul>
	  	</div>
	  </div>
	<?php
		require 'ini/footer.php';

	?>
	</body>
</html>
