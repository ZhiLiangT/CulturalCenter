#!/system/bin/sh

## application configuration
export app="/data/data/org.opendroidphp"
export sbin="${app}/components"
export assets="/sdcard/droidphp"
export busybox="$sbin/busybox/sbin/busybox"
export daemon=$1
export port=$2

## PHP fastcgi env variables
export PHP_FCGI_CHILDERN=3
export PHP_FCGI_MAX_REQUEST=1000

## execuate as deamon proccess
echo "using $daemon as http daemon"

## update server port
#change_server_port $port

## execute server

if $busybox test $daemon == "lighttpd"; then
	echo "executing lighttpd"
	$sbin/lighttpd/sbin/lighttpd \
		-f $assets/conf/lighttpd.conf \
		-D 1>/dev/null 2>&1 & PID_LIGTTPD=$!
fi

echo "executing php-cgi"
$sbin/php/sbin/php-cgi \
	-a -b $app/tmp/php.sock \
	-c $assets/conf/php.ini \
	1>/dev/null 2>&1 & PID_PHP=$!


## debugging
echo "lighttpd=$PID_LIGTTPD php=$PID_PHP mysql=$PID_MYSQL"
#toolbox log ${1+"$@"}
